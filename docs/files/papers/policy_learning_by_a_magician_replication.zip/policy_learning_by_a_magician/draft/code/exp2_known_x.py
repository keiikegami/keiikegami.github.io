"""Main learning experiment: known covariate distributions, effects learned from an RCT.

Run from draft/.  No demand sample is drawn.  MA maximizes Gamma_k(B(h))*Jhat(h);
EB maximizes Jhat(h) subject to the exact condition B(h)<=k.  Each selected rule
is evaluated with the exact eligibility labels.  Magician welfare is Gamma*J;
finite-state recursions independently check this identity and equality of every
eligible applicant's treatment probability on eight orders, for every selected
rule.  FCFS welfare and minimum probability are exact worst cases over block
orders.  Existing exp2_learning.py/results/exp2.json retain the estimated-demand
extension and are not overwritten.
"""
import hashlib
import json
import math
import os
import time
from pathlib import Path

import numpy as np

from designs import ThresholdDesign, main_design, population
from magician import evaluate_fcfs, evaluate_magician

BASE_SEED = 20261023
SEED_NAMESPACE = 22
NS = [20, 80, 400, 2000]
SAMPLES = [1000, 4000, 16000, 64000]
DELTA, ETA = 0.05, 0.5
REPS = int(os.environ.get("KNOWN_X_REPS", "500"))
RESULT_PATH = Path("results/exp2_known_x.json")


def sample_effects(design, N, rep):
    """IPW sufficient statistics from N RCT draws per environment, with no demand draws."""
    rng = np.random.default_rng(np.random.SeedSequence([BASE_SEED, SEED_NAMESPACE, N, rep]))
    mh_t = np.zeros((design.S, design.G + 1))
    for s in range(design.S):
        pr = np.empty((design.G, 2, 2))
        for d in (0, 1):
            py = design.y0 + d * design.tau[s]
            pr[:, d, 1] = 0.5 * design.P[s] * py
            pr[:, d, 0] = 0.5 * design.P[s] * (1 - py)
        counts = rng.multinomial(N, pr.ravel()).reshape(design.G, 2, 2)
        scores = (2 * counts[:, 1, 1] - 2 * counts[:, 0, 1]) / N
        mh_t[s, :design.G] = np.cumsum(scores[::-1])[::-1]
    return mh_t[np.arange(design.S)[None, :], design.T]


def evaluate_rules(design, hs, n, k, pop):
    """Cache exact deployment results and check the model-to-code equality contract."""
    orders = ThresholdDesign.test_orders([n // 2, n // 2])
    O = len(orders)
    cache = {}
    chunk = max(1, int(4e6 // (O * (k + 1) * 8)))
    for start in range(0, len(hs), chunk):
        batch = hs[start:start + chunk]
        labels = np.concatenate([design.p[h][orders] for h in batch])
        gains = np.concatenate([design.mu[h][orders] for h in batch])
        levels = np.repeat(pop["Gamma"][batch], O)
        g, bad = evaluate_magician(labels, labels, levels, k)
        eligible = labels > 0
        err = np.where(eligible, np.abs(g - levels[:, None]), 0).max(1).reshape(-1, O).max(1)
        welfare = (g * gains).sum(1).reshape(-1, O)
        formula = pop["Vmag"][batch]
        welfare_err = np.abs(welfare - formula[:, None]).max(1)
        # The first two orders are both block orders, and contain both exact FCFS extrema.
        block_labels = np.concatenate([design.p[h][orders[:2]] for h in batch])
        block_gains = np.concatenate([design.mu[h][orders[:2]] for h in batch])
        fcfs_g, used = evaluate_fcfs(block_labels, k)
        fcfs_welfare = (fcfs_g * block_gains).sum(1).reshape(-1, 2).min(1)
        floor = np.where(block_labels > 0, fcfs_g, np.inf).min(1).reshape(-1, 2).min(1)
        assert not bad.any(), "reference magician became infeasible"
        assert err.max() < 1e-9, "exact labels failed the common-probability identity"
        assert welfare_err.max() < 1e-8, "recursion welfare differs from Gamma*J"
        assert used.max() <= k + 1e-8, "FCFS capacity violation"
        for j, h in enumerate(batch):
            cache[int(h)] = dict(V=float(formula[j]), floor=float(pop["Gamma"][h]),
                                 probability_error=float(err[j]), welfare_error=float(welfare_err[j]),
                                 fcfs_V=float(fcfs_welfare[j]), fcfs_floor=float(floor[j]))
    return cache


def main():
    t0 = time.time()
    design = main_design()
    ell = math.log(2 * design.S * design.J / DELTA)
    samples = {N: np.array([sample_effects(design, N, rep) for rep in range(REPS)]) for N in SAMPLES}
    results, checks = {}, {}
    for n in NS:
        counts = np.array([n // 2, n // 2])
        k = n // 4
        pop = population(design, n, k)
        feasible = pop["B"] <= k + 1e-12
        fidx = np.flatnonzero(feasible)
        selected = {}
        for N, mh in samples.items():
            Jhat = mh @ counts
            h_ma = np.argmax(Jhat * pop["Gamma"][None, :], axis=1)
            h_eb = fidx[np.argmax(Jhat[:, feasible], axis=1)]
            selected[N] = (h_ma, h_eb, Jhat)
        hs = np.unique(np.concatenate([h for value in selected.values() for h in value[:2]]))
        cache = evaluate_rules(design, hs, n, k, pop)
        checks[str(n)] = dict(selected_rules=len(hs), orders_per_rule=8,
                              max_probability_error=max(d["probability_error"] for d in cache.values()),
                              max_welfare_error=max(d["welfare_error"] for d in cache.values()),
                              all_reference_feasible=True)
        for N, (h_ma, h_eb, Jhat) in selected.items():
            eps = math.sqrt(2 * ell / N) / ETA
            # An identically zero environment has no estimation error.
            E = eps * ((design.p > 0) @ counts)
            gam_ma = pop["Gamma"][h_ma]
            cert = gam_ma * (Jhat[np.arange(REPS), h_ma] - E[h_ma])
            event = np.all(np.abs(samples[N] - design.mu) <= eps + 1e-12, axis=(1, 2))
            evaluation = {}
            for name, hvec in (("MA", h_ma), ("EBmag", h_eb), ("EBfcfs", h_eb)):
                fcfs = name == "EBfcfs"
                evaluation[name] = {"V": [cache[int(h)]["fcfs_V" if fcfs else "V"] for h in hvec],
                                    "floor": [cache[int(h)]["fcfs_floor" if fcfs else "floor"] for h in hvec]}
            results[f"{N}_{n}"] = dict(
                summary=dict(N=N, n=n, k=k, reps=REPS, eps=eps, ell=ell,
                             Vmag_star=pop["Vmag_star"], VEB=pop["VEB"], Vmag_eb=pop["Vmag_eb"],
                             h_ma_star=pop["h_ma"], h_eb_star=pop["h_eb"]),
                sel=dict(h_MA=h_ma.tolist(), h_EB=h_eb.tolist(), G_MA=gam_ma.tolist(),
                         G_EB=pop["Gamma"][h_eb].tolist(), cert_MA=cert.tolist(), event=event.tolist()),
                eval=evaluation,
                B_over_k={"MA": (pop["B"][h_ma] / k).tolist(), "EB": (pop["B"][h_eb] / k).tolist()},
                checks=checks[str(n)])
            val = np.mean(evaluation["MA"]["V"]) / pop["Vmag_star"]
            print(f"N={N:6d} n={n:4d}: MA welfare/V*={val:.4f}; exact-probability error "
                  f"{checks[str(n)]['max_probability_error']:.2g}", flush=True)
    source_paths = [Path("code/exp2_known_x.py"), Path("code/designs.py"), Path("code/magician.py")]
    source_paths += [Path(f"code/cache/gamma_curve_k{k}_s{800 if k <= 100 else 3200}_b4.json")
                     for k in [n // 4 for n in NS]]
    metadata = dict(known_covariate_distribution=True, demand_sample=False, base_seed=BASE_SEED,
                    seed_namespace=SEED_NAMESPACE, N_per_environment=SAMPLES, deployment_sizes=NS,
                    replications=REPS, exact_recursion_checks=checks,
                    gamma_safety_margin=0.0002,
                    source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths},
                    runtime_seconds=time.time() - t0)
    RESULT_PATH.parent.mkdir(exist_ok=True)
    RESULT_PATH.write_text(json.dumps(dict(metadata=metadata, settings=results), indent=1) + "\n")
    print(f"Saved {RESULT_PATH}; {time.time() - t0:.1f} seconds", flush=True)


if __name__ == "__main__":
    main()
