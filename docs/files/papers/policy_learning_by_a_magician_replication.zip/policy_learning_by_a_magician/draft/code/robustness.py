"""Appendix E.3: robustness to departures from Assumption 1 (main design, population level, exact).

(b) Composition outside the envelope: the magician calibrated to (n/2, n/2) faces a composition
    with a different share of environment 1.
(c) Drift within environments: eligibility rates rise linearly over the deployment, violating
    Assumption 1(ii).
Outputs: results/robustness.json, figures/fig_robustness.pdf
`python3 code/robustness.py fig` rebuilds the figure from results/robustness.json.
"""
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from designs import ThresholdDesign, main_design, population  # noqa: E402
from magician import curve, evaluate_fcfs, evaluate_magician  # noqa: E402
import plotstyle as ps  # noqa: E402


def _orders_for(counts):
    return ThresholdDesign.test_orders(counts)


def part_b(ks=(20, 100), share_grid=None):
    d = main_design()
    res = {}
    for k in ks:
        n = 4 * k
        pop = population(d, n, k)
        h = pop["h_ma"]
        p, mu = d.p[h], d.mu[h]
        lev = float(pop["Gamma"][h])
        shares = np.arange(n // 4, 3 * n // 4 + 1, max(1, n // 40)) if share_grid is None else share_grid
        # robust level: worst composition in the envelope [n/4, 3n/4]
        B_rob = max(c1 * p[0] + (n - c1) * p[1] for c1 in (n // 4, 3 * n // 4))
        lev_rob = float(curve(k)(B_rob))
        rows = []
        for c1 in shares:
            counts = [int(c1), int(n - c1)]
            orders = _orders_for(counts)
            lab = p[orders]
            g_nom, bad = evaluate_magician(lab, lab, lev, k)
            g_rob, _ = evaluate_magician(lab, lab, lev_rob, k)
            g_f, _ = evaluate_fcfs(lab, k)
            el = lab > 0
            rows.append(dict(share1=c1 / n, B_over_k=float((c1 * p[0] + (n - c1) * p[1]) / k),
                             floor_nom=float(np.where(el, g_nom, np.inf).min()),
                             floor_rob=float(np.where(el, g_rob, np.inf).min()),
                             floor_fcfs=float(np.where(el, g_f, np.inf).min()),
                             W_nom=float((g_nom * mu[orders]).sum(1).min() / n),
                             infeasible=bool(bad.any())))
        res[k] = dict(level=lev, level_rob=lev_rob, p=p.tolist(), rows=rows)
        print(f"(b) k={k}: nominal level {lev:.3f}, robust {lev_rob:.3f}; floor at share .25/.5/.75: "
              f"{rows[0]['floor_nom']:.3f}/{rows[len(rows)//2]['floor_nom']:.3f}/{rows[-1]['floor_nom']:.3f}", flush=True)
    return res


def part_c(ks=(20, 100), drifts=np.linspace(0, 0.3, 16)):
    d = main_design()
    res = {}
    for k in ks:
        n = 4 * k
        pop = population(d, n, k)
        h = pop["h_ma"]
        p, mu = d.p[h], d.mu[h]
        lev = float(pop["Gamma"][h])
        orders = _orders_for([n // 2, n // 2])
        lab = p[orders]
        ramp = (2 * np.arange(n) / (n - 1) - 1)[None, :]
        rows = []
        for dr in drifts:
            tru = np.clip(lab * (1 + dr * ramp), 0, 1)
            g_nom, _ = evaluate_magician(lab, tru, lev, k)
            lev_rob = float(curve(k)((1 + dr) * pop["B"][h]))
            g_rob, _ = evaluate_magician(np.minimum(1, lab * (1 + dr)), tru, lev_rob, k)
            g_f, _ = evaluate_fcfs(tru, k)
            el = tru > 0
            rows.append(dict(drift=float(dr), floor_nom=float(np.where(el, g_nom, np.inf).min()),
                             floor_rob=float(np.where(el, g_rob, np.inf).min()), level_rob=lev_rob,
                             floor_fcfs=float(np.where(el, g_f, np.inf).min())))
        res[k] = dict(level=lev, rows=rows)
        print(f"(c) k={k}: level {lev:.3f}; floor at drift 0/.1/.2/.3: "
              + "/".join(f"{r['floor_nom']:.3f}" for r in rows[::5]), flush=True)
    return res


def figure(B, C, k=20):
    plt = ps.plt
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.75), sharey=True)
    rows = B[k]["rows"]
    x = [r["share1"] for r in rows]
    axes[0].plot(x, [r["floor_nom"] for r in rows], color=ps.BLUE, lw=ps.LW, label="magician, equal regional shares")
    axes[0].plot(x, [r["floor_rob"] for r in rows], color=ps.AQUA, lw=ps.LW,
                 label="magician, shares in $[1/4,3/4]$")
    axes[0].plot(x, [r["floor_fcfs"] for r in rows], color=ps.ORANGE, lw=ps.LW, label="FCFS")
    axes[0].axvline(0.5, color=ps.MUTED, lw=0.5)
    axes[0].set_xlabel("Share of applicants from region A")
    rows = C[k]["rows"]
    x = [r["drift"] for r in rows]
    axes[1].plot(x, [r["floor_nom"] for r in rows], color=ps.BLUE, lw=ps.LW, label="magician: actual training probability")
    axes[1].axhline(C[k]["level"], color=ps.BLUE, lw=0.9, ls=(0, (1, 1.5)), label="magician: calibrated training probability")
    axes[1].plot(x, [r["floor_fcfs"] for r in rows], color=ps.ORANGE, lw=ps.LW, label="FCFS")
    axes[1].set_xlabel("Drift $d$ (eligibility rates rise from\n$(1-d)p_s$ to $(1+d)p_s$ over the arrival sequence)")
    axes[0].set_ylabel("Minimum training probability\nof an eligible applicant")
    axes[0].set_ylim(0, 1.0)
    axes[0].legend(fontsize=7, loc="center right", bbox_to_anchor=(1.0, 0.45))
    axes[1].legend(fontsize=7, loc="center right", bbox_to_anchor=(1.0, 0.42))
    fig.tight_layout(); fig.savefig("figures/fig_robustness.pdf"); plt.close(fig)


if __name__ == "__main__":
    os.makedirs("results", exist_ok=True); os.makedirs("figures", exist_ok=True)
    if len(sys.argv) > 1 and sys.argv[1] == "fig":
        d = json.load(open("results/robustness.json"))
        figure({int(k): v for k, v in d["b"].items()}, {int(k): v for k, v in d["c"].items()})
        sys.exit(0)
    B = part_b()
    C = part_c()
    json.dump(dict(b={str(k): v for k, v in B.items()}, c={str(k): v for k, v in C.items()}),
              open("results/robustness.json", "w"))
    figure(B, C)
    print("robustness done")
