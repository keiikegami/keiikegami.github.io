"""Numerical tools for the gamma-conservative magician (exact recursions; no simulation)."""
import numpy as np

def feasible_vec(x, k, gammas):
    """For each gamma in gammas, is the gamma-conservative magician feasible on label sequence x?"""
    g = np.asarray(gammas, float)[:, None]
    G = len(g)
    dist = np.zeros((G, k + 1)); dist[:, 0] = 1.0
    ok = np.ones(G, bool)
    for xi in x:
        ok &= dist[:, :k].sum(1) >= g[:, 0] - 1e-12
        below = np.cumsum(dist, 1) - dist
        with np.errstate(divide="ignore", invalid="ignore"):
            op = np.where(dist > 0, np.clip((g - below) / dist, 0, 1), (g - below > 0).astype(float))
        op[:, k] = 0.0
        flow = dist * op * xi
        dist = dist - flow
        dist[:, 1:] += flow[:, :-1]
    return ok

def gamma_star(x, k, rounds=4, width=64):
    """max feasible gamma for the finite sequence x (grid refinement)."""
    lo, hi = 0.0, 1.0
    for _ in range(rounds):
        grid = np.linspace(lo, hi, width)
        ok = feasible_vec(x, k, grid)
        if ok.all():
            return hi
        j = np.flatnonzero(ok).max() if ok.any() else 0
        lo, hi = grid[j], grid[min(j + 1, width - 1)]
    return lo

def gamma_poisson(B, k, N):
    """Euler/Poisson-limit approximation with N equal labels B/N (decreases to the limit as N grows)."""
    return gamma_star(np.full(N, B / N), k)

def horizon_curve(k, gammas, dt, tmax):
    """For each gamma: first label mass t at which the Poisson-limit magician becomes infeasible."""
    g = np.asarray(gammas, float)[:, None]
    G = len(g)
    dist = np.zeros((G, k + 1)); dist[:, 0] = 1.0
    T = np.full(G, tmax)
    alive = np.ones(G, bool)
    t = 0.0
    while t < tmax and alive.any():
        bad = alive & (dist[:, :k].sum(1) < g[:, 0] - 1e-12)
        T[bad] = t; alive &= ~bad
        below = np.cumsum(dist, 1) - dist
        with np.errstate(divide="ignore", invalid="ignore"):
            op = np.where(dist > 0, np.clip((g - below) / dist, 0, 1), 0.0)
        op[:, k] = 0.0
        flow = dist * op * dt
        dist = dist - flow
        dist[:, 1:] += flow[:, :-1]
        t += dt
    return T
