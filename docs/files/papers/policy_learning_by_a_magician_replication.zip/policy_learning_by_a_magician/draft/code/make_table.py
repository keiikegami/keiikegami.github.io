"""Table 1: Gamma_k(B) by bisection on N and 2N equal labels with Richardson extrapolation.

Run from the draft/ directory; writes code/gamma_table.json.
"""
import json, os, sys, time
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gamma_tools import gamma_poisson
ks = [1, 2, 3, 4, 5, 10, 20, 50, 100]
betas = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]
out = {}
t0 = time.time()
for k in ks:
    row = {}
    for b in betas:
        B = b * k
        N1 = int(max(4000, 200 * B)); N2 = 2 * N1
        v1, v2 = gamma_poisson(B, k, N1), gamma_poisson(B, k, N2)
        row[b] = dict(N1=v1, N2=v2, extrap=2 * v2 - v1)
    out[k] = row
    print(k, {b: round(row[b]["extrap"], 4) for b in betas}, f"diff N1-N2 max {max(abs(row[b]['N1']-row[b]['N2']) for b in betas):.1e}", f"{time.time()-t0:.0f}s", flush=True)
json.dump({str(k): {str(b): v for b, v in r.items()} for k, r in out.items()}, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "gamma_table.json"), "w"), indent=1)
