"""Tables for the main experiment with known covariate distributions (run from draft/)."""
import json
from pathlib import Path

import numpy as np

from exp2_known_x import NS, SAMPLES, RESULT_PATH


def stats(d):
    s, ev, sel = d["summary"], d["eval"], d["sel"]
    out = dict(N=s["N"], n=s["n"], k=s["k"], reps=s["reps"], Vstar=s["Vmag_star"] / s["n"])
    for name in ("MA", "EBmag", "EBfcfs"):
        v = np.asarray(ev[name]["V"])
        out[name] = dict(W=100 * v.mean() / s["Vmag_star"],
                         W_se=100 * v.std(ddof=1) / (s["Vmag_star"] * np.sqrt(s["reps"])),
                         probability=float(np.mean(ev[name]["floor"])))
    for name, key in (("MA", "MA"), ("EBmag", "EB")):
        out[name]["B"] = float(np.mean(d["B_over_k"][key]))
    out["certificate_percent"] = 100 * float(np.mean(sel["cert_MA"])) / s["Vmag_star"]
    out["certificate_coverage"] = float(np.mean(np.array(ev["MA"]["V"]) >= np.array(sel["cert_MA"]) - 1e-9))
    out["gain_event_frequency"] = float(np.mean(sel["event"]))
    out["max_probability_error"] = d["checks"]["max_probability_error"]
    return out


def table(summary, Ns, path):
    lines = [r"\setlength{\tabcolsep}{4.1pt}", r"\begin{tabular}{rr ccc cc cc}", r"\toprule",
             r" & & \multicolumn{3}{c}{Magician-adjusted EWM} & \multicolumn{2}{c}{EB-EWM, magician} & \multicolumn{2}{c}{EB-EWM, FCFS}\\",
             r"\cmidrule(lr){3-5}\cmidrule(lr){6-7}\cmidrule(lr){8-9}",
             r"$n$ & $k$ & gain & $B/k$ & prob. & gain & $B/k$ & gain & min.\ prob.\\"]
    for N in Ns:
        lines += [r"\midrule", r"\multicolumn{9}{l}{\emph{$N=" + f"{N:,}".replace(",", "{,}") + r"$ per region}}\\"]
        for n in NS:
            a = summary[f"{N}_{n}"]
            lines.append(f"{n} & {a['k']} & {a['MA']['W']:.1f} & {a['MA']['B']:.2f} & {a['MA']['probability']:.3f} & "
                         f"{a['EBmag']['W']:.1f} & {a['EBmag']['B']:.2f} & {a['EBfcfs']['W']:.1f} & {a['EBfcfs']['probability']:.3f}\\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    Path(path).write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    results = json.loads(RESULT_PATH.read_text())
    summary = {key: stats(d) for key, d in results["settings"].items()}
    Path("tables").mkdir(exist_ok=True)
    table(summary, [4000, 64000], "tables/tab_exp2_known_x.tex")
    table(summary, SAMPLES, "tables/tab_exp2_known_x_full.tex")
    Path("results/exp2_known_x_summary.json").write_text(json.dumps(summary, indent=1) + "\n")
    for N in SAMPLES:
        group = [summary[f"{N}_{n}"] for n in NS]
        print(N, {name: [round(s[name]["W"], 3) for s in group] for name in ("MA", "EBmag", "EBfcfs")},
              "certificate %", [round(s["certificate_percent"], 2) for s in group])
    assert min(s["certificate_coverage"] for s in summary.values()) == 1
    assert max(s["max_probability_error"] for s in summary.values()) < 1e-9
