"""Section 6.1 and Figure 3: the price of arrival neutrality and what is learned (population level).

Outputs (relative to the draft/ directory):
  results/exp1.json, tables/tab_exp1.tex (Table 1), figures/fig_dilution.pdf (Figure 3)
All quantities are exact finite-state calculations with known primitives.
`python3 code/exp1_population.py report` rebuilds the table and the figure from results/exp1.json.
"""
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from designs import ThresholdDesign, main_design, population, fcfs_eval, magician_eval  # noqa: E402
from magician import curve, evaluate_fcfs  # noqa: E402
import plotstyle as ps  # noqa: E402

KS = [5, 20, 100, 500]


def table_rows():
    d = main_design()
    rows, profiles = [], {}
    for k in KS:
        t0 = time.time()
        n = 4 * k
        counts = [n // 2, n // 2]
        pop = population(d, n, k)
        orders = ThresholdDesign.test_orders(counts)
        VEB = pop["VEB"]
        h_eb, h_ma = pop["h_eb"], pop["h_ma"]
        # expected-budget rule under FCFS (worst order is a block order; Lemma in Appendix)
        W_eb_f, fl_eb_f, g_eb_f = fcfs_eval(d, h_eb, orders, k)
        o_worst = int(np.argmin(W_eb_f))
        # magician implementations with exact labels
        W_ma, fl_ma, _, bad1 = magician_eval(d, h_ma, orders, k, pop["Gamma"][h_ma])
        W_ebm, fl_ebm, _, bad2 = magician_eval(d, h_eb, orders, k, pop["Gamma"][h_eb])
        assert not bad1.any() and not bad2.any()
        # best FCFS rule: maximise worst-order FCFS welfare over the class (worst order = a block order)
        blocks = orders[:2]
        lab = d.p[:, blocks]                     # J x 2 x n
        g, _ = evaluate_fcfs(lab.reshape(-1, n), k)
        W = (g * d.mu[:, blocks].reshape(-1, n)).sum(1).reshape(d.J, 2)
        elig = lab.reshape(-1, n) > 0
        fl = np.where(elig, g, np.inf).min(1).reshape(d.J, 2)
        h_f = int(np.argmax(W.min(1)))
        W_f_all, fl_f_all, g_f = fcfs_eval(d, h_f, orders, k)
        row = dict(k=k, n=n, VEB=VEB,
                   ma=dict(t=d.T[h_ma].tolist(), p=d.p[h_ma].tolist(), B_over_k=float(pop["B"][h_ma] / k),
                           Gamma=float(pop["Gamma"][h_ma]), V=float(W_ma.min()), V_spread=float(W_ma.max() - W_ma.min())),
                   eb=dict(t=d.T[h_eb].tolist(), p=d.p[h_eb].tolist(), B_over_k=float(pop["B"][h_eb] / k),
                           Gamma=float(pop["Gamma"][h_eb]), V_mag=float(W_ebm.min()),
                           V_fcfs=float(W_eb_f.min()), V_fcfs_best_order=float(W_eb_f.max()),
                           floor_fcfs=float(fl_eb_f.min()), worst_order=o_worst),
                   fcfs_best=dict(t=d.T[h_f].tolist(), p=d.p[h_f].tolist(), B_over_k=float(pop["B"][h_f] / k),
                                  V=float(W_f_all.min()), floor=float(fl_f_all.min())),
                   Gamma_k_k=float(curve(k)(k)), alaei=1 - 1 / np.sqrt(k + 3))
        rows.append(row)
        profiles[k] = dict(pos=((np.arange(n) + 0.5) / n).tolist(),
                           fcfs_eb=g_eb_f[o_worst].tolist(),
                           fcfs_best=g_f[int(np.argmin(W_f_all))].tolist(),
                           mag_ma=row["ma"]["Gamma"], mag_eb=row["eb"]["Gamma"],
                           env=orders[o_worst].tolist())
        print(f"k={k}: MA B/k={row['ma']['B_over_k']:.2f} G={row['ma']['Gamma']:.3f} V/VEB={row['ma']['V']/VEB:.3f} | "
              f"EB+mag {row['eb']['V_mag']/VEB:.3f} | EB+FCFS {row['eb']['V_fcfs']/VEB:.3f} floor {row['eb']['floor_fcfs']:.3f} | "
              f"bestFCFS B/k={row['fcfs_best']['B_over_k']:.2f} {row['fcfs_best']['V']/VEB:.3f} floor {row['fcfs_best']['floor']:.3f} "
              f"[{time.time()-t0:.0f}s]", flush=True)
    return rows, profiles


def dilution(ks=(1, 5, 20, 100, 500), u0s=np.linspace(0.0, 0.74, 75)):
    """S=1, X~U(0,1), tau(u)=u-u0, k/n=1/4: demand of the magician-adjusted threshold rule."""
    t = np.linspace(0.0, 1.0, 4001)
    out = {}
    for k in ks:
        n = 4 * k
        p = 1 - t
        Gam = curve(k)(n * p)
        res = []
        for u0 in u0s:
            m = (1 - t ** 2) / 2 - u0 * (1 - t)
            obj = Gam * n * m
            j = int(np.argmax(obj))
            res.append(dict(u0=float(u0), t=float(t[j]), B_over_k=float(n * p[j] / k),
                            V=float(obj[j] / n), VEB=float(max(0.0, ((1 - 0.75 ** 2) / 2 - u0 * 0.25))),
                            V_ebmag=float(curve(k)(k) * ((1 - 0.75 ** 2) / 2 - u0 * 0.25))))
        out[k] = res
        print(f"dilution k={k}: B*/k at u0=0,.5,.65,.74 ->",
              [round(r["B_over_k"], 3) for r in res if round(r["u0"], 2) in (0.0, 0.5, 0.65, 0.74)], flush=True)
    return out


def make_table(rows, path):
    lines = [r"\begin{tabular}{r ccc c cc cc}", r"\toprule",
             r" & \multicolumn{4}{c}{Magician (arrival-neutral)} & \multicolumn{4}{c}{First come, first served}\\",
             r"\cmidrule(lr){2-5}\cmidrule(lr){6-9}",
             r" & \multicolumn{3}{c}{Magician-adjusted rule} & EB rule & \multicolumn{2}{c}{EB rule}"
             r" & \multicolumn{2}{c}{Best rule under FCFS}\\",
             r"\cmidrule(lr){2-4}\cmidrule(lr){5-5}\cmidrule(lr){6-7}\cmidrule(lr){8-9}",
             r"$k$ & $B/k$ & prob. & gain & gain & gain & min.\ prob. & gain & min.\ prob.\\",
             r"\midrule"]
    for r in rows:
        V = r["VEB"]
        lines.append(f"{r['k']} & {r['ma']['B_over_k']:.2f} & {r['ma']['Gamma']:.3f} & {100*r['ma']['V']/V:.1f} & "
                     f"{100*r['eb']['V_mag']/V:.1f} & {100*r['eb']['V_fcfs']/V:.1f} & {r['eb']['floor_fcfs']:.3f} & "
                     f"{100*r['fcfs_best']['V']/V:.1f} & {r['fcfs_best']['floor']:.3f}\\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(path, "w").write("\n".join(lines) + "\n")


def make_figure(dil):
    plt = ps.plt
    fig, ax = plt.subplots(figsize=(5.4, 2.9))
    cols = ps.ramp(len(dil))
    for c, (k, res) in zip(cols, dil.items()):
        u0 = [r["u0"] for r in res]; b = [r["B_over_k"] for r in res]
        ax.plot(u0, b, color=c, lw=ps.LW, label=f"$k={k}$")
    ax.axhline(1.0, color=ps.INK2, lw=0.8, ls=(0, (4, 2)), label="expected-budget rule")
    ax.set_xlabel(r"Score at which the effect turns positive, $u_0$")
    ax.set_ylabel("Expected number of\neligible applicants / capacity, $B/k$")
    ax.set_yscale("log"); ax.set_ylim(0.68, 2.15)
    ax.set_yticks([0.7, 0.8, 1, 1.25, 1.5, 2]); ax.set_yticklabels(["0.7", "0.8", "1", "1.25", "1.5", "2"])
    ax.minorticks_off()
    ax.legend(fontsize=7.5, ncol=2, loc="upper right")
    fig.tight_layout(); fig.savefig("figures/fig_dilution.pdf"); plt.close(fig)


if __name__ == "__main__":
    os.makedirs("results", exist_ok=True); os.makedirs("tables", exist_ok=True); os.makedirs("figures", exist_ok=True)
    if len(sys.argv) > 1 and sys.argv[1] == "report":
        d = json.load(open("results/exp1.json"))
        make_table(d["rows"], "tables/tab_exp1.tex")
        make_figure({int(k): v for k, v in d["dilution"].items()})
        sys.exit(0)
    rows, profiles = table_rows()
    dil = dilution()
    json.dump(dict(rows=rows, profiles={str(k): v for k, v in profiles.items()},
                   dilution={str(k): v for k, v in dil.items()}), open("results/exp1.json", "w"))
    make_table(rows, "tables/tab_exp1.tex")
    make_figure(dil)
    print("exp1 done")
