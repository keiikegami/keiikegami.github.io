"""Core tools for "Policy Learning with a Magician" (exact finite-state recursions).

Conventions
-----------
* A label sequence x = (x_1, ..., x_n) gives the probabilities that successive
  applicants are eligible.  W_i is the number of slots used before applicant i.
* The gamma-conservative magician opens its gate on the states with the fewest
  used slots first, up to total reference mass gamma.  In flow form, the mass
  that leaves state w is  min{pi(w), [gamma - pi({0,...,w-1})]_+}  (state k is
  closed: explicit stop).
* Gamma_k(B) (the order-free guarantee curve) is computed from the Poisson-limit
  system: the explicit Euler scheme with equal labels h is the magician itself;
  we record the first label mass at which P(W >= k) exceeds 1 - gamma, for a
  grid of gamma, with steps h and h/2, and Richardson-extrapolate.
No random deployment simulation is used anywhere.
"""
from __future__ import annotations

import json
import os
from functools import lru_cache

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "cache")


# ----------------------------------------------------------------------------
# Magician flows
# ----------------------------------------------------------------------------
def open_mass(dist, gamma, k):
    """Reference mass opened in each state (last axis = used slots 0..k).

    dist: (..., k+1) reference distribution; gamma broadcastable to dist[..., 0].
    Returns array of the same shape: min{dist(w), [gamma - dist(<w)]_+}, 0 at w=k.
    """
    below = np.cumsum(dist, axis=-1) - dist
    g = np.asarray(gamma, float)[..., None] if np.ndim(gamma) else gamma
    m = np.minimum(dist, np.clip(g - below, 0.0, None))
    m[..., k] = 0.0
    return m


def opening_probs(dist, gamma, k):
    """Gate opening probabilities phi(w) of the gamma-conservative magician.

    States with zero reference mass below the quantile open fully (they are
    unreachable under exact labels; opening them keeps phi nonincreasing).
    """
    below = np.cumsum(dist, axis=-1) - dist
    g = np.asarray(gamma, float)[..., None] if np.ndim(gamma) else gamma
    rem = g - below
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        phi = np.where(dist > 0, np.clip(rem / np.where(dist > 0, dist, 1.0), 0.0, 1.0),
                       (rem > 1e-15).astype(float))
    phi[..., k] = 0.0
    return phi


def feasible(x, k, gamma, tol=1e-12):
    """Is the gamma-conservative magician feasible on label sequence x?  gamma may be a vector."""
    g = np.atleast_1d(np.asarray(gamma, float))
    dist = np.zeros((len(g), k + 1)); dist[:, 0] = 1.0
    ok = np.ones(len(g), bool)
    for xi in x:
        if xi <= 0:
            continue
        ok &= dist[:, :k].sum(1) >= g - tol
        f = open_mass(dist, g, k) * xi
        dist = dist - f
        dist[:, 1:] += f[:, :-1]
    return ok if np.ndim(gamma) else bool(ok[0])


def gamma_star(x, k, tol=1e-9):
    """Largest feasible level gamma*_k(x) (bisection; feasible levels form an interval)."""
    x = np.asarray(x, float)
    if feasible(x, k, 1.0):
        return 1.0
    lo, hi = 1.0 / (1.0 + x.sum()), 1.0          # lower bound from the Markov argument
    if not feasible(x, k, lo):
        lo = 0.0
    # vectorised refinement: 32 interior points per round
    while hi - lo > tol:
        grid = np.linspace(lo, hi, 34)[1:-1]
        ok = feasible(x, k, grid)
        if ok.all():
            lo = grid[-1]
        elif not ok.any():
            hi = grid[0]
        else:
            j = np.flatnonzero(ok).max()
            lo, hi = grid[j], grid[j + 1]
    return float(lo)


# ----------------------------------------------------------------------------
# Poisson-limit guarantee curve Gamma_k(B)
# ----------------------------------------------------------------------------
def _gamma_grid():
    lin = np.linspace(0.02, 0.97, 600)
    near1 = 1.0 - np.logspace(-7, np.log10(0.03), 400)
    return np.unique(np.r_[lin, near1])


def infeasibility_times(k, gammas, h, tmax):
    """Label mass T(gamma) at which P(W >= k) first exceeds 1-gamma, for equal labels h.

    Linear interpolation inside the crossing step.  Returns tmax where no crossing occurs.
    """
    g = np.asarray(gammas, float)
    G = len(g)
    dist = np.zeros((G, k + 1)); dist[:, 0] = 1.0
    T = np.full(G, float(tmax))
    alive = np.ones(G, bool)
    t = 0.0
    idx = np.arange(G)
    while t < tmax - 1e-12 and alive.any():
        a = idx[alive]
        d = dist[a]
        f = open_mass(d, g[a], k) * h
        new = d - f
        new[:, 1:] += f[:, :-1]
        thr = 1.0 - g[a]
        cross = new[:, k] > thr
        if cross.any():
            old = d[cross, k]
            frac = (thr[cross] - old) / np.maximum(new[cross, k] - old, 1e-300)
            T[a[cross]] = t + h * np.clip(frac, 0.0, 1.0)
            alive[a[cross]] = False
        dist[a] = new
        t += h
    return T


class GammaCurve:
    """Order-free guarantee curve Gamma_k(B) with a conservative safety margin.

    value(B) returns max(0, Gamma_k(B) - margin).  The margin (default 2e-4) exceeds the
    Richardson-extrapolated discretisation error measured in tests, so the returned level is
    a valid (slightly conservative) lower bound on gamma*_k(x) for every x with sum x <= B.
    """

    def __init__(self, k, steps_per_k=800, bmax_over_k=4.0, margin=2e-4):
        self.k, self.margin = int(k), float(margin)
        fn = os.path.join(CACHE, f"gamma_curve_k{k}_s{steps_per_k}_b{bmax_over_k:g}.json")
        if os.path.exists(fn):
            d = json.load(open(fn))
            self.gam, self.T = np.array(d["gamma"]), np.array(d["T"])
        else:
            gam = _gamma_grid()
            if k == 1:
                T = 1.0 / gam - 1.0                            # Gamma_1(B) = 1/(1+B)
            else:
                h = k / steps_per_k
                tmax = bmax_over_k * k + 2 * h
                T1 = infeasibility_times(k, gam, h, tmax)
                T2 = infeasibility_times(k, gam, h / 2, tmax)
                T = np.where((T1 < tmax - 1e-9) & (T2 < tmax - 1e-9), 2 * T2 - T1, np.minimum(T1, T2))
            # T must be nonincreasing in gamma
            T = np.minimum.accumulate(T)
            self.gam, self.T = gam, T
            os.makedirs(CACHE, exist_ok=True)
            json.dump({"k": k, "gamma": gam.tolist(), "T": T.tolist()}, open(fn, "w"))
        # interpolation arrays: B increasing <-> gamma decreasing
        self._B = self.T[::-1].copy()
        self._g = self.gam[::-1].copy()
        keep = np.r_[True, np.diff(self._B) > 0]
        self._B, self._g = self._B[keep], self._g[keep]

    def exact(self, B):
        """Interpolated Gamma_k(B) without the safety margin."""
        B = np.asarray(B, float)
        out = np.interp(B, self._B, self._g, left=1.0, right=np.nan)
        if self.k == 1:
            out = 1.0 / (1.0 + B)
        out = np.where(B <= 0, 1.0, out)
        if np.any(np.isnan(out)):
            raise ValueError(f"B outside the tabulated range for k={self.k}")
        return out

    def __call__(self, B):
        B = np.asarray(B, float)
        return np.where(B <= 0, 1.0, np.maximum(0.0, self.exact(B) - self.margin))


@lru_cache(maxsize=None)
def curve(k):
    # finer steps for large k keep the extrapolated curve within ~3e-5 of the limit
    return GammaCurve(k, steps_per_k=800 if k <= 100 else 3200)


# ----------------------------------------------------------------------------
# Exact evaluation of gate-form mechanisms along fixed orders
# ----------------------------------------------------------------------------
def evaluate_fcfs(labels, k):
    """FCFS along each order.  labels: (O, n) true eligibility probabilities.

    Returns g (O, n): probability that the gate is open (= treatment probability if eligible),
    and the expected number treated (O,).
    """
    labels = np.atleast_2d(np.asarray(labels, float))
    O, n = labels.shape
    dist = np.zeros((O, k + 1)); dist[:, 0] = 1.0
    g = np.empty((O, n))
    for i in range(n):
        g[:, i] = dist[:, :k].sum(1)
        f = dist.copy(); f[:, k] = 0.0
        f *= labels[:, i:i + 1]
        dist -= f
        dist[:, 1:] += f[:, :-1]
    return g, (dist * np.arange(k + 1)).sum(1)


def evaluate_magician(ref_labels, true_labels, gamma, k, check=True):
    """Magician run with reference labels ref_labels at level gamma, applicants eligible with
    probabilities true_labels (both (O, n)); gamma scalar or (O,).

    Returns (g, infeasible) where g (O, n) is the gate-opening probability under the truth and
    infeasible (O,) flags orders on which the reference process violated feasibility at a
    position with a positive reference label (the explicit stop is always applied).
    """
    ref = np.atleast_2d(np.asarray(ref_labels, float))
    tru = np.atleast_2d(np.asarray(true_labels, float))
    O, n = ref.shape
    gam = np.broadcast_to(np.asarray(gamma, float), (O,)).copy()
    rdist = np.zeros((O, k + 1)); rdist[:, 0] = 1.0
    tdist = np.zeros((O, k + 1)); tdist[:, 0] = 1.0
    g = np.empty((O, n))
    bad = np.zeros(O, bool)
    for i in range(n):
        phi = opening_probs(rdist, gam, k)
        if check:
            bad |= (ref[:, i] > 0) & (rdist[:, :k].sum(1) < gam - 1e-9)
        g[:, i] = (tdist * phi).sum(1)
        # reference update
        fr = rdist * phi * ref[:, i:i + 1]
        rdist -= fr
        rdist[:, 1:] += fr[:, :-1]
        # truth update (explicit stop: phi(k)=0)
        ft = tdist * phi * tru[:, i:i + 1]
        tdist -= ft
        tdist[:, 1:] += ft[:, :-1]
    return g, bad


def evaluate_gates(phi, true_labels, k):
    """General gate tensor phi (O, n, k+1) with phi[..., k] = 0; returns g (O, n)."""
    tru = np.atleast_2d(np.asarray(true_labels, float))
    O, n = tru.shape
    dist = np.zeros((O, k + 1)); dist[:, 0] = 1.0
    g = np.empty((O, n))
    for i in range(n):
        p = phi[:, i]
        g[:, i] = (dist * p).sum(1)
        f = dist * p * tru[:, i:i + 1]
        dist -= f
        dist[:, 1:] += f[:, :-1]
    return g
