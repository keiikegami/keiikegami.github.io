"""Figures 1-2 of the paper (exact recursions; run from the draft/ directory)."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from magician import curve, evaluate_fcfs, gamma_star  # noqa: E402
import plotstyle as ps  # noqa: E402

plt = ps.plt
os.makedirs("figures", exist_ok=True)

# ---------- Figure 1: treatment probability by arrival position ----------
n, k = 100, 50
x = np.r_[np.full(50, 0.9), np.full(50, 0.5)]          # high-demand environment arrives first
g_fcfs, _ = evaluate_fcfs(x[None], k)
g_fcfs = g_fcfs[0]
gstar = gamma_star(x, k)
gfree = float(curve(k).exact(x.sum()))
fig, ax = plt.subplots(figsize=(6.0, 3.0))
pos = np.arange(1, n + 1)
ax.plot(pos, g_fcfs, color=ps.ORANGE, lw=ps.LW, label="First come, first served")
ax.plot([1, n], [gfree, gfree], color=ps.BLUE, lw=ps.LW,
        label=f"Magician at level $\\Gamma_{{50}}(70)={gfree:.3f}$")
ax.axvline(50.5, color=ps.MUTED, lw=0.5)
ax.text(25, 0.16, "environment 1\n($p=0.9$)", ha="center", fontsize=8.5, color=ps.INK2)
ax.text(80, 0.16, "environment 2\n($p=0.5$)", ha="center", fontsize=8.5, color=ps.INK2)
ax.set_xlabel("Arrival position"); ax.set_ylabel("Treatment probability\nif eligible")
ax.set_ylim(0, 1.05); ax.set_xlim(1, n)
ax.legend(fontsize=7.5, loc="center left", bbox_to_anchor=(0.0, 0.42))
fig.tight_layout(); fig.savefig("figures/fig_position.pdf"); plt.close(fig)
print(f"fig1: gamma*={gstar:.4f} order-free={gfree:.4f} FCFS at 60={g_fcfs[59]:.3f} at 75={g_fcfs[74]:.3f} last={g_fcfs[-1]:.3f}")

# ---------- Figure 2: guarantee curves ----------
fig, ax = plt.subplots(figsize=(6.0, 3.2))
ks = (1, 4, 20, 100)
for c, kk in zip(ps.ramp(len(ks)), ks):
    beta = np.linspace(0.2, 3.0, 281)
    G = curve(kk).exact(beta * kk)
    ax.plot(beta, G, color=c, lw=ps.LW, label=f"$k={kk}$")
beta = np.linspace(0.2, 3.0, 300)
ax.plot(beta, np.minimum(1, 1 / beta), color=ps.INK2, lw=0.8, ls=(0, (4, 2)), label=r"$\min\{1,k/B\}$")
ax.set_xlabel("Sum of break probabilities / number of wands, $B/k$")
ax.set_ylabel(r"$\Gamma_k(B)$")
ax.set_ylim(0, 1.03); ax.legend(fontsize=7.5)
fig.tight_layout(); fig.savefig("figures/fig_gamma_curves.pdf"); plt.close(fig)

print("figures 1-2 done")
