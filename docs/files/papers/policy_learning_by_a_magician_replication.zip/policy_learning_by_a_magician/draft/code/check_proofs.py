"""Numerical sanity checks of the proofs (exact recursions on random instances).

Writes results/check_proofs.json.  Every check reports the worst violation found; all should be
at the level of floating-point error.
"""
import itertools
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from magician import (curve, evaluate_fcfs, evaluate_gates, feasible, gamma_star,  # noqa: E402
                      open_mass, opening_probs)

rng = np.random.default_rng(20261023)
out = {}


def reference(x, k, g, cap=None):
    """Reference distributions on {0,...,len(x)} (uncapped); returns list of pi_i."""
    L = len(x) + 1
    pi = np.zeros(L); pi[0] = 1.0
    res = [pi.copy()]
    for xi in x:
        below = np.cumsum(pi) - pi
        o = np.minimum(pi, np.clip(g - below, 0, None))
        f = o * xi
        pi = pi - f
        pi[1:] += f[:-1]
        res.append(pi.copy())
    return res


def psi(pi, c):
    w = np.arange(len(pi))
    return float((np.maximum(w - c, 0) * pi).sum())


# Lemma A.1: recursion (mag-rec) and the feasibility criterion
worst_rec, mismatch = 0.0, 0
for _ in range(400):
    k = int(rng.integers(1, 6)); n = int(rng.integers(2, 12))
    x = rng.uniform(0, 1, n) * rng.uniform(0.2, 1.0)
    g = rng.uniform(0.2, 0.99)
    pis = reference(x, k, g)
    P = np.zeros(k)                                   # triangular recursion c = 0..k-1
    crit = True
    for i, xi in enumerate(x):
        for c in range(k):
            worst_rec = max(worst_rec, abs(P[c] - psi(pis[i], c)))
        if xi > 0 and P[k - 1] > 1 - g + 1e-12:
            crit = False
        Pm1 = np.r_[P[0] + 1, P[:-1]]
        P = P + xi * np.clip(g - 1 + Pm1 - P, 0, None)
    if crit != feasible(x, k, g):
        mismatch += 1
out["lemmaA1_recursion_max_abs_error"] = worst_rec
out["lemmaA1_feasibility_mismatches"] = mismatch


# Theorem 1(a): convex-order domination against random rules with floor gamma
def random_rule(x, k, g):
    """Random stock-dependent rule with P(A_i=1|Z_i=1) = g exactly at every position (if possible)."""
    dist = np.zeros(k + 1); dist[0] = 1.0
    out_ = [dist.copy()]
    for xi in x:
        if dist[:k].sum() < g - 1e-12:
            return None
        w = np.r_[rng.uniform(0.05, 1, k), 0.0]
        lo, hi = 0.0, 1e6
        for _ in range(100):
            mid = (lo + hi) / 2
            o = np.minimum(1, mid * w); o[k] = 0
            lo, hi = (mid, hi) if (dist * o).sum() < g else (lo, mid)
        o = np.minimum(1, hi * w); o[k] = 0
        f = dist * o * xi
        dist = dist - f; dist[1:] += f[:-1]
        out_.append(dist.copy())
    return out_


viol, tested = 0, 0
for _ in range(400):
    k = int(rng.integers(1, 5)); n = int(rng.integers(2, 10))
    x = np.clip(rng.uniform(0, 1, n) * rng.uniform(0.3, 1.2), 0, 1)
    g = rng.uniform(0.2, 0.9)
    other = random_rule(x, k, g)
    if other is None:
        continue
    tested += 1
    if not feasible(x, k, g):
        viol += 1
        continue
    pis = reference(x, k, g)
    for i in range(len(other)):
        for c in range(-1, k + 1):
            if psi(pis[i], c) > psi(np.r_[other[i], np.zeros(max(0, len(pis[i]) - k - 1))][:len(pis[i])], c) + 1e-10:
                viol += 1
out["thm1_rules_tested"] = tested
out["thm1_violations"] = viol

# Lemma A.2: splitting and monotonicity
worst_split, worst_mono = 0.0, 0.0
for _ in range(300):
    k = int(rng.integers(1, 5)); n = int(rng.integers(2, 8))
    x = rng.uniform(0, 1, n)
    j = int(rng.integers(0, n)); y = rng.uniform(0, x[j])
    xs = np.r_[x[:j], y, x[j] - y, x[j + 1:]]
    worst_split = max(worst_split, gamma_star(xs, k) - gamma_star(x, k))
    x2 = np.clip(x + rng.uniform(0, 0.3, n), 0, 1)
    worst_mono = max(worst_mono, gamma_star(x2, k) - gamma_star(x, k))
out["lemmaA2_split_max_increase"] = worst_split
out["lemmaA2_monotone_max_increase"] = worst_mono

# Theorem 2(iii): k = 1 closed form
err = 0.0
for _ in range(200):
    n = int(rng.integers(1, 9)); x = rng.uniform(0.01, 1, n)
    err = max(err, abs(gamma_star(x, 1) - 1 / (1 + x[:-1].sum())))
out["thm2iii_k1_max_abs_error"] = err

# Theorem 2(iv): scaling inequality on the computed curves
worst_scale = 0.0
for k in (1, 4, 5, 20, 100):
    C = curve(k)
    B = np.linspace(0.05 * k, 3.5 * k, 200)
    G = C.exact(B)
    for i in range(len(B)):
        for j in range(i, len(B)):
            worst_scale = max(worst_scale, B[i] / B[j] * G[i] - G[j], G[j] - G[i])
out["thm2iv_scaling_max_violation"] = worst_scale

# Lemma A.3: monotone coupling for random gate rules that are nonincreasing in the stock
worst_l2 = 0.0
for _ in range(300):
    k = int(rng.integers(1, 6)); n = int(rng.integers(2, 15))
    phi = np.sort(rng.uniform(0, 1, (1, n, k + 1)), axis=-1)[..., ::-1].copy(); phi[..., k] = 0
    x = rng.uniform(0, 1, (1, n)); x2 = np.clip(x + rng.uniform(0, 0.4, (1, n)), 0, 1)
    worst_l2 = max(worst_l2, float((evaluate_gates(phi, x2, k) - evaluate_gates(phi, x, k)).max()))
out["lemmaA3_max_violation"] = worst_l2

# Lemma E.1: worst orders under FCFS (brute force over all orders)
bad_w, bad_f = 0, 0
for _ in range(150):
    S = int(rng.integers(2, 4)); counts = rng.integers(1, 4, S); n = int(counts.sum())
    k = int(rng.integers(1, n))
    p = rng.uniform(0, 1, S); p[rng.uniform(size=S) < 0.15] = 0.0
    tau = rng.uniform(-0.5, 1, S); mu = p * tau
    base = np.repeat(np.arange(S), counts)
    orders = np.array(sorted(set(itertools.permutations(base))))
    g, _ = evaluate_fcfs(p[orders], k)
    W = (g * mu[orders]).sum(1)
    tb = np.where(p > 0, tau, np.inf)
    sorted_block = np.repeat(np.argsort(tb, kind="stable"), counts[np.argsort(tb, kind="stable")])
    gs, _ = evaluate_fcfs(p[sorted_block][None], k)
    Ws = float((gs[0] * mu[sorted_block]).sum())
    if Ws > W.min() + 1e-10:
        bad_w += 1
    elig = p[orders] > 0
    fl = np.where(elig, g, np.inf).min()
    if np.isfinite(fl):
        pos = p[p > 0].min(); s_last = int(np.flatnonzero((p == pos) & (counts > 0))[0])
        others = np.r_[np.delete(base, np.flatnonzero(base == s_last)[0]), s_last]
        go, _ = evaluate_fcfs(p[others][None], k)
        if abs(go[0, -1] - fl) > 1e-10:
            bad_f += 1
out["lemmaE1_welfare_counterexamples"] = bad_w
out["lemmaE1_floor_counterexamples"] = bad_f

os.makedirs("results", exist_ok=True)
json.dump(out, open("results/check_proofs.json", "w"), indent=1)
for key, v in out.items():
    print(f"{key}: {v}")
