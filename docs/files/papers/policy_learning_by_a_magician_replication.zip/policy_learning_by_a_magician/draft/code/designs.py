"""Data-generating processes and rule classes used in the simulations.

ThresholdDesign: S environments, G score cells per environment with probabilities P[s, j],
conditional average treatment effects tau[s, j], control outcome Y(0) ~ Bernoulli(y0).
Rules are environment-specific thresholds: h_s(j) = 1{j >= t_s}, t_s in {0, ..., G}
(t_s = G makes nobody eligible in environment s), so the class is closed under masks.
"""
from __future__ import annotations

import itertools
import math

import numpy as np

from magician import curve, evaluate_fcfs, evaluate_magician


class ThresholdDesign:
    def __init__(self, P, tau, y0=0.4, name="design"):
        self.P = np.asarray(P, float)
        self.tau = np.asarray(tau, float)
        self.S, self.G = self.P.shape
        self.y0 = float(y0)
        self.name = name
        if np.any(self.y0 + self.tau < 0) or np.any(self.y0 + self.tau > 1):
            raise ValueError("outcome probabilities outside [0,1]")
        # rule grid: all threshold vectors
        self.T = np.array(list(itertools.product(range(self.G + 1), repeat=self.S)))  # J x S
        self.J = len(self.T)
        # population p_s(t), mu_s(t) for t = 0..G (tail sums)
        tailP = np.concatenate([np.cumsum(self.P[:, ::-1], 1)[:, ::-1], np.zeros((self.S, 1))], 1)
        tailM = np.concatenate([np.cumsum((self.P * self.tau)[:, ::-1], 1)[:, ::-1], np.zeros((self.S, 1))], 1)
        self.p_t, self.mu_t = tailP, tailM                     # S x (G+1)
        s_idx = np.arange(self.S)[None, :]
        self.p = tailP[s_idx, self.T]                          # J x S
        self.mu = tailM[s_idx, self.T]                         # J x S
        self.mask_index = self._mask_index()

    def _mask_index(self):
        """mask_index[h, A] = index of the rule h^A (environments outside A masked)."""
        J, S, G = self.J, self.S, self.G
        base = (G + 1) ** np.arange(S - 1, -1, -1)
        out = np.empty((J, 2 ** S), int)
        for A in range(2 ** S):
            keep = np.array([(A >> s) & 1 for s in range(S)], bool)
            Tm = np.where(keep[None, :], self.T, G)
            out[:, A] = Tm @ base
        return out

    def rule_index(self, t):
        base = (self.G + 1) ** np.arange(self.S - 1, -1, -1)
        return int(np.asarray(t) @ base)

    # ------------------------------------------------------------------
    # sampling sufficient statistics
    # ------------------------------------------------------------------
    def sample(self, rng, m, N):
        """Demand sample (m per environment) and RCT (N per environment, D ~ Bern(1/2)).

        Returns q (J x S), mu_hat (J x S)."""
        S, G = self.S, self.G
        q_t = np.zeros((S, G + 1)); mh_t = np.zeros((S, G + 1))
        for s in range(S):
            cnt = rng.multinomial(m, self.P[s])
            q_t[s, :G] = np.cumsum(cnt[::-1])[::-1] / m
            # RCT: cell x D x Y
            pr = np.empty((G, 2, 2))
            for d in (0, 1):
                py = self.y0 + d * self.tau[s]
                pr[:, d, 1] = 0.5 * self.P[s] * py
                pr[:, d, 0] = 0.5 * self.P[s] * (1 - py)
            c = rng.multinomial(N, pr.ravel()).reshape(G, 2, 2)
            score = (2.0 * c[:, 1, 1] - 2.0 * c[:, 0, 1]) / N        # IPW with e = 1/2
            mh_t[s, :G] = np.cumsum(score[::-1])[::-1]
        s_idx = np.arange(S)[None, :]
        return q_t[s_idx, self.T], mh_t[s_idx, self.T]

    # ------------------------------------------------------------------
    # orders
    # ------------------------------------------------------------------
    @staticmethod
    def test_orders(counts, n_random=4, seed=20261023):
        """Block orders (both directions), alternating orders, and random permutations."""
        counts = list(counts)
        S = len(counts)
        assert S == 2
        n = sum(counts)
        orders = [[0] * counts[0] + [1] * counts[1], [1] * counts[1] + [0] * counts[0]]
        for first in (0, 1):
            o, left = [], list(counts)
            cur = first
            while len(o) < n:
                if left[cur] > 0:
                    o.append(cur); left[cur] -= 1
                cur = 1 - cur
            orders.append(o)
        rng = np.random.default_rng(seed)
        base = np.array([0] * counts[0] + [1] * counts[1])
        for _ in range(n_random):
            orders.append(list(rng.permutation(base)))
        return np.array(orders, int)


def main_design():
    """Two environments, 20 score cells each (uniform), linear CATEs in the score."""
    G = 20
    u = (np.arange(G) + 0.5) / G
    P = np.full((2, G), 1.0 / G)
    tau = np.vstack([0.05 + 0.35 * u,            # environment 1: modest, flat-ish effects
                     -0.30 + 0.90 * u])          # environment 2: steep, targetable effects
    return ThresholdDesign(P, tau, y0=0.4, name="main")


# ----------------------------------------------------------------------
# population quantities
# ----------------------------------------------------------------------
def population(design, n, k, counts=None):
    """Oracle rules and values for composition counts (default n/2 each)."""
    if counts is None:
        counts = np.array([n // 2, n - n // 2])
    counts = np.asarray(counts)
    B = design.p @ counts
    J = design.mu @ counts
    Gam = curve(k)(B)
    Vmag = Gam * J
    h_ma = int(np.argmax(Vmag))
    feas = B <= k + 1e-12
    h_eb = int(np.flatnonzero(feas)[np.argmax(J[feas])])
    return dict(B=B, J=J, Gamma=Gam, Vmag=Vmag, h_ma=h_ma, h_eb=h_eb,
                Vmag_star=float(Vmag[h_ma]), VEB=float(J[h_eb]),
                Vmag_eb=float(Vmag[h_eb]))


def fcfs_eval(design, h, orders, k):
    """Exact FCFS welfare and gate probabilities for rule h along each order."""
    p, mu = design.p[h], design.mu[h]
    g, used = evaluate_fcfs(p[orders], k)
    W = (g * mu[orders]).sum(1)
    elig = p[orders] > 0
    floor = np.where(elig, g, np.inf).min(1)
    return W, floor, g


def magician_eval(design, h, orders, k, gamma, ref_p=None):
    p, mu = design.p[h], design.mu[h]
    ref = p if ref_p is None else ref_p
    g, bad = evaluate_magician(ref[orders], p[orders], gamma, k)
    W = (g * mu[orders]).sum(1)
    elig = p[orders] > 0
    floor = np.where(elig, g, np.inf).min(1)
    return W, floor, g, bad
