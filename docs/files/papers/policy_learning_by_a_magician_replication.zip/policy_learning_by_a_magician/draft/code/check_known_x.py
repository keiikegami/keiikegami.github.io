"""Read-only model-to-code audit of the saved known-X learning experiment.

Run from draft/: python3 code/check_known_x.py.  Reconstruct all RCT samples,
verify both optimization criteria, the certificate and oracle comparison, and
re-evaluate every distinct selected rule using finite-state deployment recursions.
This checks numerical implementation; it is not a proof of the statistical theorem.
"""
import hashlib
import json
from pathlib import Path

import numpy as np

from designs import main_design, population
from exp2_known_x import evaluate_rules, sample_effects
from exp2_known_x_report import stats, table


def main():
    data = json.loads(Path("results/exp2_known_x.json").read_text())
    metadata, settings = data["metadata"], data["settings"]
    for path, expected in metadata["source_sha256"].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path
    design = main_design()
    expected_summary = json.loads(Path("results/exp2_known_x_summary.json").read_text())
    max_prob_error = 0.0
    checked_rules = 0
    samples = {N: np.array([sample_effects(design, N, rep) for rep in range(metadata["replications"])])
               for N in metadata["N_per_environment"]}
    for n in metadata["deployment_sizes"]:
        c = np.array([n // 2, n // 2])
        pop = population(design, n, n // 4)
        records = [settings[f"{N}_{n}"] for N in metadata["N_per_environment"]]
        rules = np.unique([h for rec in records for key in ("h_MA", "h_EB") for h in rec["sel"][key]])
        recursions = evaluate_rules(design, rules, n, n // 4, pop)
        checked_rules += len(rules)
        max_prob_error = max(max_prob_error, max(r["probability_error"] for r in recursions.values()))
        for rec in records:
            summary, sel, ev = rec["summary"], rec["sel"], rec["eval"]
            N, reps = summary["N"], summary["reps"]
            Jhat = samples[N] @ c
            ma, eb = np.array(sel["h_MA"]), np.array(sel["h_EB"])
            ma_objective = Jhat * pop["Gamma"][None, :]
            assert np.allclose(ma_objective[np.arange(reps), ma], ma_objective.max(1), atol=1e-12)
            eligible_eb = pop["B"] <= n // 4 + 1e-12
            assert eligible_eb[eb].all()
            assert np.allclose(Jhat[np.arange(reps), eb], Jhat[:, eligible_eb].max(1), atol=1e-12)
            E = summary["eps"] * ((design.p > 0) @ c)
            certificate = pop["Gamma"][ma] * (Jhat[np.arange(reps), ma] - E[ma])
            assert np.allclose(certificate, sel["cert_MA"], atol=1e-12)
            for name, indices in (("MA", ma), ("EBmag", eb), ("EBfcfs", eb)):
                for out, source in (("V", "fcfs_V" if name == "EBfcfs" else "V"),
                                    ("floor", "fcfs_floor" if name == "EBfcfs" else "floor")):
                    truth = [recursions[int(h)][source] for h in indices]
                    assert np.allclose(ev[name][out], truth, atol=1e-10)
            assert np.all(np.array(ev["MA"]["V"]) <= pop["Vmag_star"] + 1e-10)
            assert stats(rec) == expected_summary[f"{N}_{n}"]
    print(json.dumps(dict(settings=len(settings), training_samples=len(samples) * metadata["replications"],
                          selected_rule_deployment_checks=checked_rules, orders_per_rule=8,
                          maximum_probability_discrepancy=max_prob_error,
                          optimization_certificate_evaluation_and_source_hash_checks="passed"), indent=2))


if __name__ == "__main__":
    main()
