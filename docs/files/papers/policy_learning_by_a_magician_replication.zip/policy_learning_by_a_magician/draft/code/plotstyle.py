"""Shared matplotlib style for the paper's figures.

Colours: the first three slots of a validated categorical palette (all-pairs CVD
separation >= 9.2, normal-vision >= 24; checked with the dataviz validator against a
white page) and a single-hue ordinal ramp (blue, light -> dark) for ordered series such
as capacities.  Colour carries the mechanism (magician = blue, first-come-first-served =
orange, other = aqua); line style carries the eligibility rule, so identity never rests on
colour alone.  Serif text matches the LaTeX document.
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

plt.rcParams.update({
    "font.size": 9, "font.family": "serif", "mathtext.fontset": "cm",
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 0.6, "axes.edgecolor": "#52514e", "axes.labelcolor": "#0b0b0b",
    "xtick.color": "#52514e", "ytick.color": "#52514e",
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "lines.solid_capstyle": "round", "lines.solid_joinstyle": "round",
    "legend.handlelength": 2.4, "legend.frameon": False,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})

BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, INK2, MUTED = "#0b0b0b", "#52514e", "#898781"
RAMP = ["#86b6ef", "#5598e7", "#2a78d6", "#1c5cab", "#104281"]     # ordinal blue 250..650
LW = 1.5


def ramp(n):
    """n ordered blues from the validated ordinal ramp (light -> dark)."""
    if n <= len(RAMP):
        idx = [round(i * (len(RAMP) - 1) / max(n - 1, 1)) for i in range(n)]
        return [RAMP[i] for i in idx]
    raise ValueError("more ordered series than ramp steps; facet instead")
