"""Learning curves from the saved known-X experiment; no simulation reruns.

The two learned rules use the same magician. The vertical normalization is the
population optimum under that magician, separately for each capacity.
"""
from pathlib import Path
import hashlib
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "draft/code"))
import plotstyle as ps
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FixedFormatter

SOURCE = ROOT / "draft/results/exp2_known_x_summary.json"
summary = json.loads(SOURCE.read_text())
SAMPLES = [1000, 4000, 16000, 64000]
CAPACITIES = [5, 20, 100, 500]
plt = ps.plt
plt.rcParams.update({"font.size": 10, "axes.labelsize": 10,
                     "xtick.labelsize": 9, "ytick.labelsize": 9,
                     "pdf.fonttype": 42, "ps.fonttype": 42})
fig, axs = plt.subplots(2, 2, figsize=(8, 5.5), sharex=True, sharey=True)
fig.subplots_adjust(left=.105, right=.98, bottom=.14, top=.88, hspace=.29, wspace=.16)
records = []
for j, (ax, k) in enumerate(zip(axs.flat, CAPACITIES)):
    data = [summary[f"{N}_{4*k}"] for N in SAMPLES]
    assert all(r["k"] == k and r["reps"] == 500 for r in data)
    ax.set_title(f"({chr(97+j)}) $k={k}$", loc="left", fontsize=11, pad=9)
    ax.axhline(100, color=ps.MUTED, lw=.9, ls=(0, (2, 3)), zorder=1)
    for method, color, marker, ls, z in [
        ("EBmag", ps.INK2, "s", "--", 2),
        ("MA", ps.BLUE, "o", "-", 3),
    ]:
        mean = np.array([r[method]["W"] for r in data])
        se = np.array([r[method]["W_se"] for r in data])
        ax.errorbar(SAMPLES, mean, yerr=1.96*se, fmt=marker, linestyle=ls,
                    color=color, linewidth=1.65, markersize=4.8,
                    markerfacecolor="white" if method == "EBmag" else color,
                    markeredgewidth=1.0, elinewidth=.8, capsize=2.5, capthick=.8,
                    zorder=z)
        for r, m, e in zip(data, mean, se):
            records.append({"k": k, "N": r["N"], "method": method,
                            "mean_welfare_percent": float(m), "monte_carlo_se": float(e),
                            "interval_lower": float(m-1.96*e), "interval_upper": float(m+1.96*e)})
    gap = data[-1]["MA"]["W"] - data[-1]["EBmag"]["W"]
    ax.text(.97, .065, "Difference at $N=64{,}000$:\n" + f"{gap:+.2f} percentage points",
            ha="right", va="bottom", transform=ax.transAxes, fontsize=9,
            color=ps.INK2, linespacing=1.35)
    ax.set_xscale("log")
    ax.set_xlim(800, 80000)
    ax.set_ylim(92, 100.6)
    ax.set_yticks([92, 94, 96, 98, 100])
    ax.xaxis.set_major_locator(FixedLocator(SAMPLES))
    ax.xaxis.set_major_formatter(FixedFormatter(["1,000", "4,000", "16,000", "64,000"]))
    ax.minorticks_off()
    ax.grid(axis="y", color="#e8e8e6", linewidth=.55)
    ax.set_axisbelow(True)

fig.supylabel("Employment gain (% of best rule under magician)", x=.015, fontsize=10.5)
fig.supxlabel("Experimental participants per region, $N$", y=.035, fontsize=10.5)
handles = [Line2D([0], [0], color=ps.BLUE, marker="o", lw=1.65, ms=4.8,
                  label="Magician-adjusted EWM"),
           Line2D([0], [0], color=ps.INK2, marker="s", markerfacecolor="white",
                  linestyle="--", lw=1.65, ms=4.8, label="EB-EWM")]
fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(.55, .995),
           ncol=2, fontsize=10, columnspacing=2.5)
out = ROOT / "draft/figures/fig_learning_curves"
fig.savefig(out.with_suffix(".pdf"), metadata={"Title": "Learning the effects of training: employment gains and experimental sample size", "CreationDate": None})
fig.savefig(out.with_suffix(".png"), dpi=220)
plt.close(fig)

provenance = {
    "source": str(SOURCE.relative_to(ROOT)),
    "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "generator": str(Path(__file__).relative_to(ROOT)),
    "scope": "Known regional score distributions, 441 pairs of eligibility cutoffs, n=4k. Each method uses the same exact-label magician and is evaluated on the same 500 experimental samples per setting; welfare is the expected employment gain from job training.",
    "normalization": "100 * mean deployment welfare / Vmag_star at each capacity",
    "error_bars": "Mean plus or minus 1.96 Monte Carlo SE (sample standard deviation / sqrt(500)); not the dispersion of an individual learned rule or the theoretical certificate.",
    "endpoint_difference": "Magician-adjusted EWM minus EB-EWM, in percentage points. No significance claim inferred from separate error bars.",
    "data": records,
    "outputs": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in [out.with_suffix(".pdf"), out.with_suffix(".png")]},
}
(ROOT / "random_thoughts/learning_figure.json").write_text(json.dumps(provenance, indent=2)+"\n")
print(f"Saved {len(records)} plotted means and their uncertainty; no new simulations.")
