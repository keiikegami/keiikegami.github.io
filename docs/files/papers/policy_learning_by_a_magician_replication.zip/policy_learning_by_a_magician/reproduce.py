#!/usr/bin/env python3
"""Reproduce the paper in a separate work directory; never edit the bundle."""
import argparse
import datetime as dt
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PYTHON = str(Path(sys.executable).absolute())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_bundle():
    manifest = ROOT / "CHECKSUMS.json"
    if not manifest.exists():
        raise RuntimeError("CHECKSUMS.json is missing; use the complete replication archive.")
    hashes = json.loads(manifest.read_text())["files"]
    bad = [name for name, expected in hashes.items()
           if not (ROOT / name).is_file() or digest(ROOT / name) != expected]
    if bad:
        raise RuntimeError("Missing or changed bundle files: " + ", ".join(bad))
    print(f"Verified {len(hashes)} bundled files.", flush=True)


def compile_manuscript(work, run):
    """Compile until cross-references settle, with a bounded number of passes."""
    (work / "draft/build").mkdir(exist_ok=True)
    tex = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "-file-line-error",
           "-output-directory=build", "main.tex"]
    run("latex-first", tex, "draft")
    run("bibliography", ["bibtex", "build/main"], "draft")
    for number in range(2, 7):
        run(f"latex-pass-{number}", tex, "draft")
        log = (work / "draft/build/main.log").read_text()
        unsettled = [line for line in log.splitlines()
                     if "undefined" in line.lower() or "Rerun to get cross-references" in line]
        if not unsettled:
            break
    else:
        raise RuntimeError("LaTeX references did not converge: " + "\n".join(unsettled))
    overfull = [line for line in log.splitlines() if "Overfull" in line]
    if overfull:
        raise RuntimeError("Final LaTeX diagnostics: " + "\n".join(overfull))
    shutil.copy2(work / "draft/build/main.pdf", work / "draft/main.pdf")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["verify", "figures", "full", "pdf"])
    parser.add_argument("--output", type=Path, help="New, empty work-directory path")
    parser.add_argument("--no-pdf", action="store_true", help="Skip LaTeX in figures/full mode")
    args = parser.parse_args()
    verify_bundle()
    if args.mode == "verify":
        return
    if args.no_pdf and args.mode == "pdf":
        parser.error("--no-pdf cannot be used with pdf mode")
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    work = (args.output or ROOT / "outputs" / f"{args.mode}-{stamp}").resolve()
    if work.exists():
        raise RuntimeError(f"Work directory already exists: {work}; choose a new path.")
    if work == ROOT or ROOT.is_relative_to(work):
        raise RuntimeError("The work directory must not contain the replication bundle.")
    for folder in ["draft", "model", "random_thoughts", "scripts"]:
        if work.is_relative_to(ROOT / folder):
            raise RuntimeError("The work directory must be outside the bundled source directories.")
    required = []
    if args.mode == "full":
        required += ["c++", "clang++"]
    if not args.no_pdf:
        required += ["pdflatex", "bibtex"]
    for command in required:
        if shutil.which(command) is None:
            raise RuntimeError(f"Required command not on PATH: {command}. See README.md.")
    versions = {}
    if args.mode != "pdf":
        for name in ["numpy", "scipy", "matplotlib"]:
            versions[name] = importlib.metadata.version(name)
    work.mkdir(parents=True)
    for folder in ["draft", "model", "random_thoughts", "scripts"]:
        shutil.copytree(ROOT / folder, work / folder,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "build"))
    (work / "logs").mkdir()
    (work / "provenance").mkdir()
    env = os.environ.copy()
    # Some original drivers invoke python3. Keep them in this interpreter's environment.
    env["PATH"] = str(Path(PYTHON).parent) + os.pathsep + env.get("PATH", "")
    env["KNOWN_X_REPS"] = "500"
    env["MPLBACKEND"] = "Agg"
    env["MPLCONFIGDIR"] = str(work / ".matplotlib")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONHASHSEED"] = "0"
    env["OMP_NUM_THREADS"] = "1"
    env["OPENBLAS_NUM_THREADS"] = "1"
    records = []
    began = time.perf_counter()

    def save_report(status):
        report = {"mode": args.mode, "status": status,
                  "started_utc": stamp, "runtime_seconds": time.perf_counter() - began,
                  "python": platform.python_version(), "platform": platform.platform(),
                  "packages": versions, "replications": 500,
                  "base_seed": 20261023, "steps": records}
        (work / "provenance/run_report.json").write_text(json.dumps(report, indent=2) + "\n")

    def run(name, argv, cwd="."):
        print(f"[{name}] starting", flush=True)
        t = time.perf_counter()
        log = work / "logs" / f"{name}.log"
        with log.open("w") as stream:
            result = subprocess.run(argv, cwd=work / cwd, env=env,
                                    stdout=stream, stderr=subprocess.STDOUT)
        records.append({"step": name, "argv": ["python" if x == PYTHON else str(x) for x in argv],
                        "cwd": cwd, "seconds": time.perf_counter() - t,
                        "returncode": result.returncode, "log": str(log.relative_to(work))})
        save_report("running")
        if result.returncode:
            raise RuntimeError(f"{name} failed. See {log}\n" + log.read_text()[-6000:])
        print(f"[{name}] completed in {records[-1]['seconds']:.1f}s", flush=True)

    def py(name, script, *extra, cwd="draft"):
        run(name, [PYTHON, script, *map(str, extra)], cwd)

    try:
        if args.mode == "full":
            # Recompute from primitives. These copies are reference targets only in ROOT.
            for directory in ["draft/results", "draft/code/cache", "model/generated/price_decomposition"]:
                shutil.rmtree(work / directory)
                (work / directory).mkdir(parents=True)
            (work / "draft/code/gamma_table.json").unlink()
            for f in (work / "draft/figures").glob("*.pdf"):
                f.unlink()
            for f in (work / "draft/tables").glob("*.tex"):
                f.unlink()
            py("guarantee-figures", "code/make_figures.py")
            py("population", "code/exp1_population.py")
            py("learning", "code/exp2_known_x.py")
            py("learning-report", "code/exp2_known_x_report.py")
            py("robustness", "code/robustness.py")
            py("guarantee-table", "code/make_table.py")
            py("recursion-diagnostics", "code/check_proofs.py")
            py("cap-certificates", "model/src/price_decomposition/cap_run.py", cwd=".")
            py("neutral-certificates", "model/src/price_decomposition/neutral.py", cwd=".")
            py("neutral-diagnostics", "model/tests/price_decomposition/neutral_checks.py", cwd=".")
            py("lp-diagnostics", "model/src/price_decomposition/lp.py", cwd=".")
        elif args.mode == "figures":
            py("guarantee-figures", "code/make_figures.py")
            py("population-report", "code/exp1_population.py", "report")
            py("learning-report", "code/exp2_known_x_report.py")
            py("robustness-figure", "code/robustness.py", "fig")
        if args.mode in ["full", "figures"]:
            py("learning-figure", "random_thoughts/plot_learning_curves.py", cwd=".")
            py("price-figure-table", "model/src/price_decomposition/plot.py", cwd=".")
        if args.mode == "full":
            py("learning-audit", "code/check_known_x.py")
            py("numerical-validation", "scripts/validate_outputs.py",
               "--reference-root", ROOT, "--work-root", work, cwd=".")
        if not args.no_pdf:
            compile_manuscript(work, run)
        verify_bundle()
        save_report("PASS")
        print(f"PASS: {work}", flush=True)
        if not args.no_pdf:
            print(f"Rebuilt manuscript: {work / 'draft/main.pdf'}", flush=True)
    except BaseException:
        save_report("FAIL")
        raise


if __name__ == "__main__":
    main()
