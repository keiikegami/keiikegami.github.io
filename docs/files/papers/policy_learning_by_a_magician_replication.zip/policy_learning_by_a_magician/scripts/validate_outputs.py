#!/usr/bin/env python3
"""Compare independently regenerated outputs with the distributed reference.

This script never generates or copies research results. The reproduction runner
must first generate the work-root outputs from code. Only the validation report
is written here. Requires Python 3.9 or later; uses only the standard library.
"""

import argparse
from datetime import datetime, timezone
from fractions import Fraction
import json
import math
import os
from pathlib import Path
import re
import sys


JSON_PATHS = (
    "draft/results/exp1.json",
    "draft/results/exp2_known_x.json",
    "draft/results/exp2_known_x_summary.json",
    "draft/results/robustness.json",
    "draft/results/check_proofs.json",
    "draft/code/gamma_table.json",
    "model/generated/price_decomposition/cap_bounds.json",
    "model/generated/price_decomposition/cap_exact_k5.json",
    "model/generated/price_decomposition/neutral.json",
    "model/generated/price_decomposition/neutral_checks.json",
    "model/generated/price_decomposition/lp_checks.json",
    "model/generated/price_decomposition/summary.json",
)
RTOL = 1e-10
ATOL = 1e-10
MAX_REPORTED_ERRORS = 100
HASH_RE = re.compile(r"[0-9a-fA-F]{64}\Z")
FRACTION_RE = re.compile(r"[+-]?\d+/[1-9]\d*\Z")
BETA_COLUMNS = ("0.5", "0.75", "1.0", "1.25", "1.5", "2.0")
PROOF_ZERO_KEYS = (
    "lemmaA1_feasibility_mismatches",
    "thm1_violations",
    "lemmaE1_welfare_counterexamples",
    "lemmaE1_floor_counterexamples",
)
# Recursion/coupling tests operate at machine precision; the finite-sequence
# bisection uses a 1e-9 stopping tolerance in magician.py.
PROOF_ERROR_LIMITS = {
    "lemmaA1_recursion_max_abs_error": 1e-12,
    "lemmaA2_split_max_increase": 2e-9,
    "lemmaA2_monotone_max_increase": 2e-9,
    "thm2iii_k1_max_abs_error": 2e-9,
    "thm2iv_scaling_max_violation": 1e-10,
    "lemmaA3_max_violation": 1e-12,
}


def hash_mapping(value):
    return (isinstance(value, dict) and bool(value)
            and all(isinstance(v, str) and HASH_RE.fullmatch(v)
                    for v in value.values()))


def ignored_field(key, value):
    normalized = key.lower().replace("_", "").replace("-", "")
    if normalized in {
        "time", "runtime", "elapsed", "seconds", "runtimeseconds",
        "elapsedseconds", "durationseconds", "walltimeseconds",
    }:
        return True
    if "sha256" in normalized or normalized in {
        "sourcehash", "sourcehashes", "provenancehash", "provenancehashes",
        "inputhash", "inputhashes", "outputhash", "outputhashes",
    }:
        return True
    return key in {"inputs", "outputs"} and hash_mapping(value)


def report_value(value):
    """Keep even a rejected NaN/Infinity representable in a strict JSON report."""
    if isinstance(value, float) and not math.isfinite(value):
        return repr(value)
    if isinstance(value, list):
        return [report_value(v) for v in value]
    if isinstance(value, dict):
        return {k: report_value(v) for k, v in value.items()}
    return value


class Audit:
    def __init__(self):
        self.errors = []
        self.error_count = 0
        self.compared_scalars = 0
        self.ignored = []

    def fail(self, path, message, expected=None, actual=None):
        self.error_count += 1
        if len(self.errors) < MAX_REPORTED_ERRORS:
            row = {"path": path, "message": message}
            if expected is not None:
                row["expected"] = report_value(expected)
            if actual is not None:
                row["actual"] = report_value(actual)
            self.errors.append(row)

    def compare(self, expected, actual, path):
        if isinstance(expected, dict):
            if not isinstance(actual, dict):
                self.fail(path, "Expected a JSON object")
                return
            left = {k for k, v in expected.items() if not ignored_field(k, v)}
            right = {k for k, v in actual.items() if not ignored_field(k, v)}
            self.ignored.extend(path + "/" + k for k in sorted(
                (set(expected) - left) | (set(actual) - right)))
            if left != right:
                self.fail(path, "Object keys differ", sorted(left), sorted(right))
            for key in sorted(left & right):
                self.compare(expected[key], actual[key], path + "/" + key)
            return
        if isinstance(expected, list):
            if not isinstance(actual, list):
                self.fail(path, "Expected a JSON array")
                return
            if len(expected) != len(actual):
                self.fail(path, "Array lengths differ", len(expected), len(actual))
            for i, (a, b) in enumerate(zip(expected, actual)):
                self.compare(a, b, path + "/" + str(i))
            return
        self.compared_scalars += 1
        # Booleans, integer counts, and integer-valued candidate selections are
        # exact comparisons, not floating-point tolerance comparisons.
        if isinstance(expected, bool) or expected is None:
            if type(actual) is not type(expected) or actual != expected:
                self.fail(path, "Exact value differs", expected, actual)
        elif isinstance(expected, int):
            if type(actual) is not int or actual != expected:
                self.fail(path, "Integer value differs", expected, actual)
        elif isinstance(expected, float):
            if (type(actual) not in (int, float) or not math.isfinite(expected)
                    or not math.isfinite(actual)
                    or not math.isclose(expected, actual, rel_tol=RTOL, abs_tol=ATOL)):
                self.fail(path, "Floating value differs or is nonfinite", expected, actual)
        elif isinstance(expected, str):
            # Outward-rounded neutral endpoints are serialized as fractions.
            # Compare those real values with the float tolerance; integer
            # numerator/denominator strings and exact-DP fractions stay exact.
            endpoint = path.rsplit("/", 1)[-1]
            approximate_fraction = endpoint.endswith("_exact") and endpoint in {
                "gamma_lower_exact", "gamma_upper_exact", "welfare_lower_exact",
                "welfare_upper_exact", "value_lower_exact", "value_upper_exact",
            }
            if (approximate_fraction and FRACTION_RE.fullmatch(expected)
                    and isinstance(actual, str) and FRACTION_RE.fullmatch(actual)):
                a, b = Fraction(expected), Fraction(actual)
                tolerance = max(Fraction.from_float(ATOL),
                                Fraction.from_float(RTOL) * max(abs(a), abs(b)))
                if abs(a - b) > tolerance:
                    self.fail(path, "Fraction endpoint differs", expected, actual)
            elif actual != expected:
                self.fail(path, "Exact string differs", expected, actual)
        elif type(actual) is not type(expected) or actual != expected:
            self.fail(path, "Exact value differs", expected, actual)


def load_json(path, audit, label):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError) as exc:
        audit.fail(label, "Cannot read required JSON: " + str(exc))
        return None


def check_proof_diagnostics(data, audit):
    prefix = "draft/results/check_proofs.json"
    start = audit.error_count
    if not isinstance(data, dict):
        audit.fail(prefix, "Missing proof-diagnostic object")
        return {"status": "FAIL"}
    zero_keys = set(PROOF_ZERO_KEYS) | {
        k for k in data if k.endswith(("_violations", "_mismatches", "_counterexamples"))
    }
    for key in sorted(zero_keys):
        if type(data.get(key)) is not int or data[key] != 0:
            audit.fail(prefix + "/" + key, "Diagnostic count must be exactly zero", 0, data.get(key))
    for key, limit in PROOF_ERROR_LIMITS.items():
        value = data.get(key)
        if (type(value) not in (int, float) or not math.isfinite(value)
                or not 0 <= value <= limit):
            audit.fail(prefix + "/" + key, "Diagnostic exceeds absolute error limit",
                       {"minimum": 0, "maximum": limit}, value)
    if type(data.get("thm1_rules_tested")) is not int or data["thm1_rules_tested"] <= 0:
        audit.fail(prefix + "/thm1_rules_tested", "No rules were checked")
    return {"status": "PASS" if audit.error_count == start else "FAIL",
            "zero_count_keys": sorted(zero_keys), "absolute_error_limits": PROOF_ERROR_LIMITS}


def check_gamma_display(data, appendix_path, audit):
    """Check all 54 extrapolated cells and the nine analytical-bound cells."""
    start = audit.error_count
    label = "draft/sections/appendix.tex:tab:curve"
    try:
        text = appendix_path.read_text(encoding="utf-8")
        if text.count(r"\label{tab:curve}") != 1:
            raise ValueError("Expected one tab:curve label")
        after_label = text.split(r"\label{tab:curve}", 1)[1]
        table = after_label.split(r"\begin{tabular}", 1)[1].split(r"\end{tabular}", 1)[0]
    except (OSError, UnicodeError, ValueError, IndexError) as exc:
        audit.fail(label, "Cannot locate required guarantee table: " + str(exc))
        return {"status": "FAIL", "cells_checked": 0}
    if not isinstance(data, dict):
        audit.fail(label, "Missing recalculated gamma-table object")
        return {"status": "FAIL", "cells_checked": 0}
    rows = {}
    for line in table.splitlines():
        match = re.fullmatch(r"\s*(\d+)\s*&(.+?)\\\\\s*", line)
        if match:
            key = match.group(1)
            if key in rows:
                audit.fail(label, "Duplicate capacity row", actual=key)
            rows[key] = [cell.strip().strip("$").strip() for cell in match.group(2).split("&")]
    if set(rows) != set(data):
        audit.fail(label, "Capacity rows differ from recomputed table", sorted(data), sorted(rows))
    cells_checked = 0
    for key in sorted(set(rows) & set(data), key=int):
        cells = rows[key]
        if len(cells) != 7:
            audit.fail(label + "/k=" + key, "Expected six Gamma cells and one Alaei bound", 7, len(cells))
            continue
        if not isinstance(data[key], dict) or set(data[key]) != set(BETA_COLUMNS):
            audit.fail(label + "/k=" + key, "Unexpected B/k columns")
            continue
        for beta, cell in zip(BETA_COLUMNS, cells[:6]):
            path = label + "/k=" + key + "/B_over_k=" + beta
            try:
                value = data[key][beta]["extrap"]
                if type(value) not in (int, float) or not math.isfinite(value):
                    raise ValueError("Extrapolated value is not finite")
                if cell.startswith(">"):
                    threshold = float(cell[1:])
                    if not value > threshold:
                        audit.fail(path, "Printed lower-bound statement fails", cell, value)
                elif re.fullmatch(r"\d+\.\d{4}", cell):
                    rounded = format(value, ".4f")
                    if cell != rounded:
                        audit.fail(path, "Printed four-decimal cell differs from recalculation",
                                   rounded, cell)
                else:
                    raise ValueError("Unrecognized numerical cell: " + cell)
                cells_checked += 1
            except (KeyError, TypeError, ValueError) as exc:
                audit.fail(path, str(exc))
        alaei = format(1 - 1 / math.sqrt(int(key) + 3), ".4f")
        if cells[6] != alaei:
            audit.fail(label + "/k=" + key + "/Alaei", "Analytical bound display differs", alaei, cells[6])
        cells_checked += 1
    return {"status": "PASS" if audit.error_count == start else "FAIL",
            "cells_checked": cells_checked, "display_digits": 4,
            "rule": "Exact displayed rounding; > cells must satisfy their printed inequality."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-root", type=Path, required=True)
    parser.add_argument("--work-root", type=Path, required=True)
    args = parser.parse_args()
    reference = args.reference_root.resolve()
    work = args.work_root.resolve()
    audit = Audit()
    if reference == work:
        audit.fail("roots", "Reference and regenerated work roots must be different")
    files = []
    fresh = {}
    for relative in JSON_PATHS:
        before = audit.error_count
        reference_path, work_path = reference / relative, work / relative
        if reference_path.is_file() and work_path.is_file() and os.path.samefile(reference_path, work_path):
            audit.fail(relative, "Reference and regenerated output resolve to the same file")
        expected = load_json(reference_path, audit, "reference/" + relative)
        actual = load_json(work_path, audit, "work/" + relative)
        if expected is not None and actual is not None:
            audit.compare(expected, actual, relative)
        fresh[relative] = actual
        files.append({"path": relative, "status": "PASS" if audit.error_count == before else "FAIL",
                      "mismatches": audit.error_count - before})
    proof = check_proof_diagnostics(fresh.get("draft/results/check_proofs.json"), audit)
    gamma = check_gamma_display(fresh.get("draft/code/gamma_table.json"),
                               work / "draft/sections/appendix.tex", audit)
    report = {
        "status": "PASS" if audit.error_count == 0 else "FAIL",
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Comparison only: all work outputs must already have been independently regenerated by the runner. This script does not establish freshness or copy/generate research results.",
        "reference_root": str(reference), "work_root": str(work),
        "tolerances": {"relative": RTOL, "absolute": ATOL,
                       "integers_booleans_candidate_selections": "exact",
                       "exact_rational_DP_values": "exact",
                       "neutral_fraction_endpoints": "numeric tolerance",
                       "gamma_table_display": "exact four-decimal rounding"},
        "files": files, "compared_scalars": audit.compared_scalars,
        "ignored_metadata_paths": sorted(set(audit.ignored)),
        "proof_diagnostics": proof, "gamma_table_display": gamma,
        "error_count": audit.error_count, "errors": audit.errors,
        "errors_truncated": audit.error_count > len(audit.errors),
    }
    report_path = work / "provenance/numerical_validation.json"
    try:
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
                               encoding="utf-8")
    except (OSError, ValueError) as exc:
        print("Cannot save validation report: " + str(exc), file=sys.stderr)
        return 2
    print(json.dumps({"status": report["status"], "files_checked": len(files),
                      "compared_scalars": audit.compared_scalars,
                      "errors": audit.error_count, "report": str(report_path)}, indent=2))
    return 0 if audit.error_count == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
