"""Full-region-prefix occupancy LPs for an oblivious fixed-order adversary.

No prefix-count merging is used. Histories are Markovized conditional on the
entire observed region prefix and used capacity. Independent future scores make
this sufficient simultaneously for all completions. HiGHS supplies primal/dual
floating-point certificates; these are numerical checks, not symbolic proofs.
"""
from __future__ import annotations
import argparse, hashlib, json, time
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix


def prefix_tree(counts):
    nodes=[()]; parents=[-1]; last=[-1]; leaves=[]
    for i,p in enumerate(nodes):
        if len(p)==sum(counts):
            leaves.append(i); continue
        for s,c in enumerate(counts):
            if p.count(s)<c:
                nodes.append(p+(s,));parents.append(i);last.append(s)
    return nodes,np.array(parents),np.array(last),leaves


class Rows:
    def __init__(self):self.r=[];self.c=[];self.v=[];self.b=[]
    def add(self, terms, rhs=0.):
        i=len(self.b)
        for j,v in terms:
            if v:self.r.append(i);self.c.append(j);self.v.append(v)
        self.b.append(rhs)
    def matrix(self,n):
        return coo_matrix((self.v,(self.r,self.c)),shape=(len(self.b),n)).tocsr(),np.array(self.b)


def solve(c,eq,ub,bounds):
    ae,be=eq.matrix(len(c));au,bu=ub.matrix(len(c))
    t=time.time();res=linprog(c,A_ub=au,b_ub=bu,A_eq=ae,b_eq=be,bounds=bounds,
                            method='highs',options={'primal_feasibility_tolerance':1e-9,
                            'dual_feasibility_tolerance':1e-9,'ipm_optimality_tolerance':1e-10})
    if not res.success:raise RuntimeError(res.message)
    lower=np.array([a if a is not None else -np.inf for a,b in bounds]);upper=np.array([b if b is not None else np.inf for a,b in bounds])
    dual=float(np.sum(be*res.eqlin.marginals)+np.sum(bu*res.ineqlin.marginals))
    f=np.isfinite(lower);dual+=float(np.sum(lower[f]*res.lower.marginals[f]))
    f=np.isfinite(upper);dual+=float(np.sum(upper[f]*res.upper.marginals[f]))
    stationarity=c-ae.T@res.eqlin.marginals-au.T@res.ineqlin.marginals-res.lower.marginals-res.upper.marginals
    check={'variables':len(c),'equalities':len(be),'inequalities':len(bu),
           'primal_equality_residual':float(np.max(np.abs(ae@res.x-be),initial=0)),
           'primal_inequality_violation':float(np.max(np.maximum(au@res.x-bu,0),initial=0)),
           'stationarity_residual':float(np.max(np.abs(stationarity),initial=0)),
           'primal_objective':float(res.fun),'dual_objective':dual,
           'duality_gap':float(abs(res.fun-dual)),
           'primal_bound_violation':float(max(np.max(np.maximum(lower-res.x,0),initial=0),np.max(np.maximum(res.x-upper,0),initial=0))),
           'min_dual_inequality_slack':float(np.min(-res.ineqlin.marginals,initial=0)),
           'status':res.message,'seconds':time.time()-t}
    assert check['primal_equality_residual']<2e-7,check
    assert check['primal_inequality_violation']<2e-7,check
    assert check['stationarity_residual']<2e-7,check
    assert check['duality_gap']<2e-7,check
    return res,check


def expected_lp(counts,k,tau,prob=None):
    tau=np.asarray(tau,float);S,G=tau.shape
    if prob is None:prob=np.full((S,G),1/G)
    weights=np.asarray(counts)[:,None]*prob
    ub=Rows();ub.add(list(enumerate(weights.ravel())),k)
    res,check=solve(-(weights*tau).ravel(),Rows(),ub,[(0,1)]*(S*G))
    return {'value':-res.fun,'selection_probabilities':res.x.reshape(S,G).tolist(),'diagnostics':check}


def cap_lp(counts,k,tau,prob=None):
    tau=np.asarray(tau,float);S,G=tau.shape
    if prob is None:prob=np.full((S,G),1/G)
    nodes,parent,last,leaves=prefix_tree(counts);N=len(nodes)
    # d[p,w] is distribution after prefix p. y[p,w,j] is probability of
    # current score j AND acceptance from previous stock w, conditional on p.
    d=np.arange(N*(k+1)).reshape(N,k+1);cur=d.size
    y={}
    for p in range(1,N):
        for w in range(min(k,len(nodes[p]))):
            for j in range(G):
                if tau[last[p],j]>0:y[p,w,j]=cur;cur+=1
    reward=np.arange(cur,cur+N);cur+=N;z=cur;cur+=1
    eq=Rows();ub=Rows()
    for w in range(k+1):eq.add([(d[0,w],1)],float(w==0))
    eq.add([(reward[0],1)])
    for p in range(1,N):
        r=parent[p];s=last[p]
        for w in range(k+1):
            terms=[(d[p,w],1),(d[r,w],-1)]
            terms += [(y[p,w,j],1) for j in range(G) if (p,w,j) in y]
            terms += [(y[p,w-1,j],-1) for j in range(G) if (p,w-1,j) in y]
            eq.add(terms)
        terms=[(reward[p],1),(reward[r],-1)]
        for w in range(min(k,len(nodes[p]))):
            for j in range(G):
                if (p,w,j) in y:
                    a=y[p,w,j]
                    ub.add([(a,1),(d[r,w],-prob[s,j])])
                    terms.append((a,-tau[s,j]))
        eq.add(terms)
    for p in leaves:ub.add([(z,1),(reward[p],-1)])
    c=np.zeros(cur);c[z]=-1
    res,check=solve(c,eq,ub,[(0,None)]*cur)
    return {'value':-res.fun,'prefixes':N,'orders':len(leaves),'diagnostics':check}


def neutral_lp(counts,k,p):
    p=np.asarray(p,float);nodes,parent,last,leaves=prefix_tree(counts);N=len(nodes)
    d=np.arange(N*(k+1)).reshape(N,k+1);cur=d.size;a={}
    for q in range(1,N):
        if p[last[q]]>0:
            for w in range(min(k,len(nodes[q]))):a[q,w]=cur;cur+=1
    gamma=cur;cur+=1;eq=Rows();ub=Rows()
    for w in range(k+1):eq.add([(d[0,w],1)],float(w==0))
    for q in range(1,N):
        r=parent[q];prob=p[last[q]]
        for w in range(k+1):
            terms=[(d[q,w],1),(d[r,w],-1)]
            if (q,w) in a:terms.append((a[q,w],prob))
            if (q,w-1) in a:terms.append((a[q,w-1],-prob))
            eq.add(terms)
        if prob>0:
            eq.add([(a[q,w],1) for w in range(min(k,len(nodes[q])))]+[(gamma,-1)])
            for w in range(min(k,len(nodes[q]))):ub.add([(a[q,w],1),(d[r,w],-1)])
    c=np.zeros(cur);c[gamma]=-1;bounds=[(0,None)]*cur;bounds[gamma]=(0,1)
    res,check=solve(c,eq,ub,bounds)
    return {'gamma':-res.fun,'prefixes':N,'orders':len(leaves),'diagnostics':check}


def descending_gamma(counts,k,p):
    labels=sorted([float(p[s]) for s,c in enumerate(counts) for _ in range(c) if p[s]>0],reverse=True)
    if len(labels)<=k:return 1.
    if k==1:return 1/(1+sum(labels[:-1]))
    lo=0.;hi=1.
    for _ in range(55):
        g=(lo+hi)/2;psi=np.zeros(k)
        for x in labels[:-1]:
            for c in range(k-1,0,-1):psi[c]+=x*max(0.,g-1+psi[c-1]-psi[c])
            psi[0]+=x*g
        if psi[-1]<=1-g:lo=g
        else:hi=g
    return lo


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--max-k',type=int,default=2);ap.add_argument('--output',default=str(Path(__file__).resolve().parents[3]/'model/generated/price_decomposition/lp_checks.json'));args=ap.parse_args()
    u=(np.arange(20)+.5)/20;tau=np.array([.05+.35*u,-.30+.90*u])
    out={'scope':'Exact full-prefix occupancy LP, oblivious fixed regional order; same current 20-score regional design. Numerical primal/dual checks, no symbolic solver certificate.','expected':[],'cap':[],'neutral':[],'neutral_optimum':[]}
    for k in range(1,args.max_k+1):
        er=expected_lp([2*k,2*k],k,tau);er['k']=k;out['expected'].append(er)
        assert abs(er['value']-.10625*4*k)<1e-10
        print('expected',k,er['value'],flush=True)
        r=cap_lp([2*k,2*k],k,tau);r['k']=k;out['cap'].append(r);print('cap',k,r['value'],r['diagnostics'],flush=True)
    for k in range(1,args.max_k+1):
        candidates=[]
        for a in range(21):
            for b in range(21):
                J=2*k*(np.sum(tau[0,20-a:])/20+np.sum(tau[1,20-b:])/20)
                if J<=0:continue
                probabilities=[a/20,b/20]
                gamma=descending_gamma([2*k,2*k],k,probabilities)
                candidates.append((gamma*J,a,b,gamma,J))
        value,a,b,gamma,J=max(candidates)
        check=neutral_lp([2*k,2*k],k,[a/20,b/20])
        assert abs(check['gamma']-gamma)<2e-8
        row={'k':k,'eligible_score_counts':[a,b],'gamma':gamma,'J':J,'value':value,'LP_gamma':check['gamma'],'LP_diagnostics':check['diagnostics']}
        out['neutral_optimum'].append(row)
        print('neutral optimum',row,flush=True)
    for counts,k in [([2,2],1),([4,4],2),([3,2],2)]:
        for p in [[.2,.3],[.25,.35],[.8,.1],[0,.7],[1,1],[.3,.3]]:
            r=neutral_lp(counts,k,p);r.update(counts=counts,k=k,p=p,descending_gamma=descending_gamma(counts,k,p));r['difference']=r['gamma']-r['descending_gamma'];out['neutral'].append(r)
            assert abs(r['difference'])<2e-8,r
            print('neutral',counts,k,p,r['gamma'],r['difference'],flush=True)
    out['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
    print('saved',args.output,flush=True)

if __name__=='__main__':main()
