"""Global optimal arrival-neutral welfare over all 441 regional cutoffs.

This is a finite-label calculation, not the mass-uniform Gamma curve.
Expected welfare is evaluated from rational design primitives. Every cutoff is
either enclosed by a certified gamma interval or excluded by a rational upper
bound. The C++ helper uses explicit nextafter outward rounding, not fast-math.
"""
from pathlib import Path
from fractions import Fraction as Q
import hashlib
import itertools
import json
import subprocess
import time
import tempfile
import argparse

ROOT = Path(__file__).resolve().parents[3]
CPP = ROOT / "model/src/price_decomposition/neutral_solver.cpp"
OUT = ROOT / "model/generated/price_decomposition/neutral.json"


def design(a, b, k):
    u = [Q(2*j-1, 40) for j in range(1, 21)]
    t1 = [Q(1,20)+Q(7,20)*x for x in u]
    t2 = [-Q(3,10)+Q(9,10)*x for x in u]
    J = Q(k,10) * (sum(t1[20-a:], Q()) + sum(t2[20-b:], Q()))
    B = Q(k*(a+b), 10)
    U = min(Q(1), Q(k)/B)*max(Q(0),J) if B else Q(0)
    return B,J,U


class Solver:
    def __init__(self):
        self.temp = tempfile.TemporaryDirectory(prefix="price-neutral-")
        exe = Path(self.temp.name)/"solver"
        subprocess.run(["clang++","-O3","-ffp-contract=off","-std=c++17",str(CPP),"-o",str(exe)],check=True)
        self.proc = subprocess.Popen([str(exe)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                                     text=True,bufsize=1)
        self.cache={}

    def gamma(self,k,m,a,b):
        key=(k,m,max(a,b),min(a,b))
        if key not in self.cache:
            self.proc.stdin.write(" ".join(map(str,key))+"\n")
            self.proc.stdin.flush()
            vals=self.proc.stdout.readline().split()
            assert len(vals)==5,(key,vals)
            lo,hi,fr,ir=map(float,vals[:4])
            assert vals[-1]=="1" and 0<=lo<=hi<=1,(key,vals)
            self.cache[key]=(Q.from_float(lo),Q.from_float(hi),fr,ir)
        return self.cache[key]

    def close(self):
        self.proc.stdin.close()
        assert self.proc.wait()==0
        self.temp.cleanup()


def global_value(k,solver):
    candidates=[]
    for a,b in itertools.product(range(21),repeat=2):
        B,J,U=design(a,b,k)
        candidates.append((U,a,b,B,J))
    candidates.sort(reverse=True)
    best=Q(0)
    records=[]
    all_upper=[]
    for U,a,b,B,J in candidates:
        row={"eligible_cells_A":a,"eligible_cells_B":b,
             "threshold_indices":[20-a,20-b],"B":float(B),"J":float(J),
             "J_exact":str(J),"capacity_upper":float(U),"capacity_upper_exact":str(U)}
        if J<=0 or U<best:
            row.update(status="excluded_by_capacity_upper",welfare_upper=float(U),
                       welfare_upper_exact=str(U))
            all_upper.append(U)
        else:
            gl,gh,fr,ir=solver.gamma(k,2*k,a,b)
            wl,wh=gl*J,gh*J
            row.update(status="evaluated",gamma_lower=float(gl),gamma_upper=float(gh),
                       gamma_lower_exact=str(gl),gamma_upper_exact=str(gh),
                       feasible_residual_upper=fr,infeasible_residual_lower=ir,
                       welfare_lower=float(wl),welfare_upper=float(wh),
                       welfare_lower_exact=str(wl),welfare_upper_exact=str(wh))
            best=max(best,wl)
            all_upper.append(wh)
        records.append(row)
    upper=max(all_upper)
    potential=[r for r in records if Q(r["welfare_upper_exact"])>=best]
    winner=max((r for r in records if r["status"]=="evaluated"),
               key=lambda r:Q(r["welfare_lower_exact"]))
    assert upper>=best>0
    return {"k":k,"n":4*k,"value_lower":float(best),"value_upper":float(upper),
            "value_lower_exact":str(best),"value_upper_exact":str(upper),
            "unique_winning_cutoff_certified":len(potential)==1,
            "potential_winners":[r["threshold_indices"] for r in potential],
            "winner":winner,"evaluated_candidates":sum(r["status"]=="evaluated" for r in records),
            "all_candidates":sorted(records,key=lambda r:r["threshold_indices"])}


def verify_flow(k,a,b,gamma):
    # Independent probability-mass recursion (rather than stop-loss coordinates).
    import numpy as np
    dist=np.zeros(k+1);dist[0]=1
    lab=sorted([a/20]*(2*k)+[b/20]*(2*k),reverse=True)
    minimum_slack=1.0
    for p in lab:
        if p==0:continue
        slack=float(dist[:k].sum()-gamma)
        minimum_slack=min(minimum_slack,slack)
        if slack<0:return False,minimum_slack
        below=np.cumsum(dist)-dist
        opened=np.minimum(dist,np.maximum(0,gamma-below));opened[k]=0
        flow=p*opened
        dist-=flow;dist[1:]+=flow[:-1]
    return True,minimum_slack


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--output",type=Path,default=OUT);args=parser.parse_args()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    start=time.time();solver=Solver()
    try:
        rows=[global_value(k,solver) for k in [5,20,100,500]]
    finally:solver.close()
    for r in rows:
        w=r["winner"];a=w["eligible_cells_A"];b=w["eligible_cells_B"]
        oklo,sl=verify_flow(r["k"],a,b,w["gamma_lower"])
        okhi,sh=verify_flow(r["k"],a,b,w["gamma_upper"])
        assert oklo and (not okhi or w["gamma_upper"]==1),(r["k"],sl,sh)
        r["independent_mass_flow_check"]={"lower_feasible":oklo,"lower_min_slack":sl,
                                             "upper_feasible":okhi,"upper_min_slack":sh}
        print({key:r[key] for key in ["k","value_lower","value_upper","unique_winning_cutoff_certified","potential_winners","evaluated_candidates"]},flush=True)
    result={"status":"exploratory_computation_with_outward_rounding_and_independent_flow_checks",
            "definition":"Optimal exact-arrival-neutral welfare over all 441 cutoff rules, every fixed regional order, and all online hard-cap implementations.",
            "order_reduction":"Delete zero labels and put larger eligibility probabilities first; adjacent-swap proof in model/proofs/price_decomposition/neutral_order.tex.",
            "zero_labels":"Skipped: no eligible applicant and no neutrality restriction at these positions.",
            "comparator":"Same original H, regional counts and online information; not restricted to the mass-only magician family.",
            "numerical_method":"Finite stop-loss recurrence; 45-step double bisection followed by outward-rounded certification of both endpoints. Rational welfare arithmetic and candidate pruning.",
            "global_optimality":"All 441 candidates evaluated or excluded by exact min(1,k/B)*max(J,0) upper bounds. Unique winner when every other upper bound is below the winning lower bound.",
            "elapsed_seconds":time.time()-start,
            "source_hashes":{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                             for p in [Path(__file__),CPP,ROOT/"draft/code/designs.py"]},
            "settings":rows}
    args.output.write_text(json.dumps(result,indent=2)+"\n")


if __name__=="__main__":main()
