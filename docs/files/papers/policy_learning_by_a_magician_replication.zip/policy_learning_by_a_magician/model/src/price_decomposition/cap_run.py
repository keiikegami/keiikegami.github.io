"""Reproduce hard-cap optimum certificates without rerunning simulations."""
from pathlib import Path
from fractions import Fraction
import hashlib
import json
import subprocess
import tempfile
import argparse

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / 'model/src/price_decomposition/cap_bounds.cpp'
EXACT = ROOT / 'model/tests/price_decomposition/cap_exact.py'
parser = argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=ROOT/'model/generated/price_decomposition')
args = parser.parse_args()
args.output_dir.mkdir(parents=True,exist_ok=True)
OUT = args.output_dir/'cap_bounds.json'
INPUT = ROOT / 'draft/code/designs.py'

with tempfile.TemporaryDirectory(prefix='price-cap-') as temp:
    binary = Path(temp) / 'bounds'
    subprocess.run(['c++','-std=c++17','-O3',str(SOURCE),'-o',str(binary)],check=True)
    rows=[]
    for k in [5,20,100,500]:
        r=json.loads(subprocess.check_output([str(binary),str(k)],text=True))
        assert int(r['lower_numerator']) <= int(r['upper_numerator'])
        r['relative_interval_width'] = r['width']/r['lower']
        rows.append(r)
        print(json.dumps(r),flush=True)
    rational = json.loads(subprocess.check_output(['python3',str(EXACT),'5'],text=True))
    lo=Fraction(int(rows[0]['lower_numerator']),int(rows[0]['denominator']))
    hi=Fraction(int(rows[0]['upper_numerator']),int(rows[0]['denominator']))
    assert rational['exact_original_optimum_certified']
    exact=Fraction(rational['lower_rational'])
    assert lo <= exact <= hi
    (args.output_dir/'cap_exact_k5.json').write_text(
        json.dumps(rational,indent=2)+'\n')

payload = {
    'status':'exploratory_computational_certificate_independently_reviewed',
    'claim':'Original fixed-oblivious-order hard-cap optimum lies in every reported interval.',
    'scope':{'counts':'n/2 applicants from each of A and B, n=4k',
             'score_probabilities':'20 equiprobable values per region',
             'effects_A':'(47+14*j)/800, j=0,...,19',
             'effects_B':'(-222+36*j)/800, j=0,...,19',
             'eligibility':'H contains all-eligible rule; unrestricted eligible-only implementations',
             'information':'Current region and score observed; future region order unknown and fixed in advance',
             'objective':'Worst fixed-order expected employment increase, true effects known'},
    'method':{'lower':'Bellman subsolution against a stronger inventory-observing region adversary',
              'upper':'Optimal online planner told the fixed block order A...AB...B in advance',
              'rounding':'Exact int64 fixed-point arithmetic, floor expectations below and ceil above',
              'certificate_note':'model/proofs/price_decomposition/cap_certificate.txt'},
    'rows':rows,
    'exact_k5':rational,
    'inputs':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
              for p in [SOURCE,EXACT,INPUT,Path(__file__)]},
    'not_claimed':['Neither endpoint is labeled the original exact optimum when the interval is nonzero.',
                   'A-before-B is not claimed to be a worst order at every capacity.',
                   'No existing simulation result or manuscript file was modified.']}
OUT.write_text(json.dumps(payload,indent=2)+'\n')
