"""Render the manuscript price decomposition from checked population results."""
from pathlib import Path
import hashlib
import json
import math
from fractions import Fraction as Q
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[3]
DATA=ROOT/'model/generated/price_decomposition'
cap_path=DATA/'cap_bounds.json'
an_path=DATA/'neutral.json'
mag_path=ROOT/'draft/results/exp1.json'
cap=json.loads(cap_path.read_text())['rows']
neutral=json.loads(an_path.read_text())['settings']
mag=json.loads(mag_path.read_text())['rows']
def down(q): return math.nextafter(float(q), -math.inf)
def up(q): return math.nextafter(float(q), math.inf)
rows=[]
for c,a,m in zip(cap,neutral,mag):
    k=c['k']; assert k==a['k']==m['k']
    e=17*k/40
    assert abs(m['VEB']-e)<1e-12
    cq0=Q(int(c['lower_numerator']),int(c['denominator'])); cq1=Q(int(c['upper_numerator']),int(c['denominator']))
    aq0=Q(a['value_lower_exact']); aq1=Q(a['value_upper_exact']); eq=Q(17*k,40)
    cl,ch=down(cq0),up(cq1); al,ah=down(aq0),up(aq1)
    cm=(cl+ch)/2; am=(al+ah)/2; vm=m['ma']['V']
    assert 0<vm<al<=ah<cl<=ch<e
    # This checks feasibility of the numerical magician level in this design.
    selected=next(x for x in a['all_candidates'] if x['threshold_indices']==m['ma']['t'])
    assert selected['status']=='evaluated'
    assert m['ma']['Gamma']<selected['gamma_lower']
    r={'k':k,'n':4*k,'V_exp':e,'V_cap_midpoint':cm,'V_cap_interval':[cl,ch],
       'V_cap_interval_width':c['width'],'V_AN_midpoint':am,'V_AN_interval':[al,ah],
       'V_mag_numerical':vm,'PoC':e/cm,'PoC_interval':[down(eq/cq1),up(eq/cq0)],
       'PoAN':cm/am,'PoAN_interval':[down(cq0/aq1),up(cq1/aq0)],
       'product':e/am,'product_interval':[down(eq/aq1),up(eq/aq0)],
       'PoM_numerical':e/vm,'neutral_to_magician':am/vm,
       'explicit_upper_bound':1/(1-1/math.sqrt(k+3)),
       'neutral_eligible_shares':[a['winner']['eligible_cells_A']/20,a['winner']['eligible_cells_B']/20],
       'magician_eligible_shares':m['ma']['p'],
       'numerical_magician_level':m['ma']['Gamma'],
       'finite_sequence_certified_feasible_level':selected['gamma_lower'],
       'numerical_magician_feasibility_certified_in_design':True}
    assert r['product']<=r['PoM_numerical']<=r['explicit_upper_bound']
    assert abs(r['PoC']*r['PoAN']-r['product'])<1e-13
    rows.append(r)
result={'status':'checked_population_comparison_with_certified_cap_and_neutral_intervals',
        'prices':'PoC=Vexp/Vcap, PoAN=Vcap/VAN, PoM=Vexp/Vmag; all >=1',
        'magician_caveat':'Existing numerical Gamma curve minus 2e-4, as used in Section 6.1; not a certified enclosure of the ideal Gamma-family optimum.',
        'cap_caveat':'Midpoints display a certified interval, not exact optima except rationally certified k=5.',
        'ratio_enclosures':'Exact Fraction endpoints propagated algebraically, then rounded outward on conversion to float.',
        'theory_curve':'Explicit Alaei bound applies to ideal Gamma; its numerical comparison is a diagnostic.',
        'inputs':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [cap_path,an_path,mag_path]},
        'rows':rows}
(DATA/'summary.json').write_text(json.dumps(result,indent=2)+'\n')

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,
    'axes.spines.top':False,'axes.spines.right':False,'axes.labelsize':11,
    'axes.titlesize':12,'xtick.labelsize':10,'ytick.labelsize':10,
    'legend.fontsize':10,'pdf.fonttype':42,'ps.fonttype':42})
fig,axes=plt.subplots(1,2,figsize=(9.6,3.95))
ks=np.array([r['k'] for r in rows])
colors={'PoC':'#277DA8','PoAN':'#D16E28','product':'#30866C','PoM_numerical':'#714697'}
def series(ax,key,label,marker):
    vals=np.array([r[key] for r in rows])
    ax.plot(ks,vals,marker=marker,color=colors[key],linewidth=1.8,markersize=5,label=label,zorder=4)
    if key+'_interval' in rows[0]:
        ints=np.array([r[key+'_interval'] for r in rows]);err=np.array([vals-ints[:,0],ints[:,1]-vals])
        ax.errorbar(ks,vals,yerr=err,fmt='none',ecolor=colors[key],capsize=3,elinewidth=1,zorder=5)
for ax in axes:
    ax.set_xscale('log');ax.set_xticks(ks);ax.set_xticklabels([str(k) for k in ks])
    ax.set_xlim(3.8,660);ax.set_xlabel('Training places, $k$')
    ax.axhline(1,color='#888888',linewidth=.8,linestyle=':')
    ax.grid(axis='y',color='#dddddd',linewidth=.6,zorder=0)
    ax.set_ylabel('Welfare ratio (1 = no cost)')
series(axes[0],'PoC','Price of exact cap','o')
series(axes[0],'PoAN','Price of arrival neutrality','s')
axes[0].set_title('(a) Two successive requirements',loc='left',pad=12)
axes[0].set_ylim(.98,1.155);axes[0].set_yticks([1,1.05,1.10,1.15])
axes[0].legend(loc='upper right',frameon=False,handlelength=1.7)
for key,dy in [('PoC',-14),('PoAN',8)]:
    for r in rows:
        axes[0].annotate(f"{r[key]:.3f}",(r['k'],r[key]),xytext=(0,8 if key=='PoC' and r['k']==100 else dy),textcoords='offset points',ha='center',color=colors[key],fontsize=9)
series(axes[1],'product','Product: exact cap × neutrality','o')
series(axes[1],'PoM_numerical','Price of magician (numerical)','D')
dense=np.geomspace(5,500,300)
axes[1].plot(dense,1/(1-1/np.sqrt(dense+3)),color='#777777',linestyle='--',linewidth=1.3,label='Proposition 1: explicit upper bound',zorder=2)
axes[1].set_title('(b) Combined cost and magician',loc='left',pad=12)
axes[1].set_ylim(.99,1.65);axes[1].set_yticks([1,1.2,1.4,1.6])
axes[1].legend(loc='upper right',frameon=False,handlelength=1.7,fontsize=9)
fig.subplots_adjust(left=.073,right=.99,bottom=.18,top=.86,wspace=.27)
for ext in ['pdf','png']:
    fig.savefig(ROOT/f'draft/figures/fig_price_decomposition.{ext}',dpi=200)
plt.close(fig)
(ROOT/'draft/figures/fig_price_decomposition.tex').write_text(r'''\begin{figure}[!htbp]
\centering
\includegraphics[width=\linewidth]{figures/fig_price_decomposition.pdf}
\caption{The prices of exact cap, arrival neutrality, and magician. Panel (a) plots $\mathrm{PoC}=V^{\mathrm{exp}}/V^{\mathrm{cap}}$ and $\mathrm{PoAN}=V^{\mathrm{cap}}/V^{\mathrm{AN}}$. Panel (b) compares their product with the numerical price of magician $\widetilde{\mathrm{PoM}}$ and the bound $[1-(k+3)^{-1/2}]^{-1}$ from \cref{prop:price}. Each program has $n=4k$ applicants, half from each region. Certified intervals for the cap and neutral optima are narrower than the plotted markers. Magician values use the same numerical curve and safety adjustment as the learning experiment; the theoretical bound concerns the exact curve.}\label{fig:price-decomposition}
\end{figure}
''')
lines=[r'\begin{table}[!htbp]',r'\centering\small',
 r'\caption{Population values underlying the price decomposition}\label{tab:price-decomposition}',
 r'\begin{tabular}{rrrrrr}',r'\toprule',
 r'$k$ & $V^{\mathrm{exp}}$ & $V^{\mathrm{cap}}$ & Interval width & $V^{\mathrm{AN}}$ & $\widetilde V^{\mathrm{mag}}_*$ \\',r'\midrule']
for r in rows:
    width=r['V_cap_interval_width']
    exponent=math.floor(math.log10(width)); mantissa=width/10**exponent
    width_tex=f'${mantissa:.2f}\\times10^{{{exponent}}}$'
    lines.append(f"{r['k']} & {r['V_exp']:.3f} & {r['V_cap_midpoint']:.6f} & {width_tex} & {r['V_AN_midpoint']:.6f} & {r['V_mag_numerical']:.6f} \\\\")
lines += [r'\bottomrule',r'\end{tabular}',r'\smallskip',r'\begin{minipage}{0.97\linewidth}\footnotesize',
 r'\emph{Notes:} Values measure the expected increase in employed applicants. The $V^{\mathrm{cap}}$ column displays interval midpoints; the next column gives the widths of the certified intervals before display rounding. For $k=5$, an independent rational calculation establishes the exact optimum. The certified interval for $V^{\mathrm{AN}}$ has width below $5\times10^{-9}$ in every row. The optimal eligible shares in regions A and B are $(0.35,0.35)$, $(0.30,0.30)$, $(0.25,0.30)$, and $(0.20,0.30)$ for increasing $k$. Magician values retain the numerical approximation and safety adjustment used in the learning experiment.',
 r'\end{minipage}',r'\end{table}']
(ROOT/'draft/tables/tab_price_decomposition.tex').write_text('\n'.join(lines)+'\n')
print(json.dumps([{key:r[key] for key in ['k','PoC','PoAN','product','PoM_numerical']} for r in rows],indent=2))
