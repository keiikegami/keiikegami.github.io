// Exploratory certified sandwich for the fixed-order hard-cap optimum.
// The lower DP permits nature to observe realized inventory before choosing
// the next region. The upper DP reveals the fixed order A...AB...B to the planner.
// Agreement certifies the original oblivious-order problem; otherwise report
// an interval, never label either endpoint the original exact optimum.
// Rewards are exactly (47+14*j)/800 in A, (-222+36*j)/800 in B, j=0,...,19.
// Every probability is exactly 1/20. Fixed-point floors/ceilings give rigorous
// directional rounding without relying on floating-point convergence.
#include <algorithm>
#include <chrono>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <vector>

using I = std::int64_t;
constexpr I Q = 1000000000000LL;
constexpr I DEN = 800LL * Q;

I transition(const I* f, int l, int s, bool upper) {
    if (!l) return 0;
    const I delta = f[l] - f[l-1];
    assert(delta >= 0 && delta <= 462LL*Q);
    const I step = (s ? 36LL : 14LL) * Q;
    const I top = (s ? 462LL : 313LL) * Q - delta;
    if (top <= 0) return f[l];
    const I count = std::min<I>(20, (top + step - 1) / step);
    const I tail = count * top - step * count * (count-1) / 2;
    return f[l] + (tail + (upper ? 19 : 0)) / 20;
}

int main(int argc, char** argv) {
    const int k = argc > 1 ? std::atoi(argv[1]) : 5;
    if (k < 1 || k > 1000) return 2;
    const auto start = std::chrono::steady_clock::now();
    const int m = 2*k, width = k+1;
    std::vector<I> prev((m+1)*width), cur((m+1)*width);
    std::uint64_t b_strict = 0;
    // a and b are numbers of applicants still to arrive from each region.
    for (int a=0; a<=m; ++a) {
        std::fill(cur.begin(), cur.end(), 0);
        for (int b=0; b<=m; ++b) {
            if (!a && !b) continue;
            I* dest = cur.data()+b*width;
            const I* fa = prev.data()+b*width;
            const I* fb = b ? cur.data()+(b-1)*width : nullptr;
            for (int l=1; l<=k; ++l) {
                const I va = a ? transition(fa,l,0,false) : 0;
                const I vb = b ? transition(fb,l,1,false) : 0;
                dest[l] = !a ? vb : !b ? va : std::min(va,vb);
                if (a && b && vb < va) ++b_strict;
            }
        }
        prev.swap(cur);
    }
    const I lower = prev[m*width+k];
    std::vector<I> f(width), g(width);
    // Backward induction: B suffix first, then A prefix.
    for (int s : {1,0}) for (int t=0;t<m;++t) {
        g[0]=0;
        for(int l=1;l<=k;++l) g[l]=transition(f.data(),l,s,true);
        f.swap(g);
    }
    const I upper=f[k];
    const auto stop=std::chrono::steady_clock::now();
    std::cout << std::setprecision(18)
      << "{\"k\":" << k << ",\"n\":" << 4*k
      << ",\"lower_numerator\":\"" << lower << "\""
      << ",\"upper_numerator\":\"" << upper << "\""
      << ",\"denominator\":\"" << DEN << "\""
      << ",\"lower\":" << static_cast<long double>(lower)/DEN
      << ",\"upper\":" << static_cast<long double>(upper)/DEN
      << ",\"width\":" << static_cast<long double>(upper-lower)/DEN
      << ",\"strict_B_choices_in_lower_DP\":" << b_strict
      << ",\"seconds\":" << std::chrono::duration<double>(stop-start).count()
      << "}\n";
}
