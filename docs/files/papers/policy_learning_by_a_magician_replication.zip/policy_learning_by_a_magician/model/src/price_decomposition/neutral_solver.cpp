#include <algorithm>
#include <cfenv>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <vector>

// Exact finite-sequence recurrence, evaluated numerically. Inputs are k,
// number of applicants per region m, and numbers of eligible score cells a,b.
// Robustness to every fixed regional order follows from the adjacent-swap
// proof in price_decomposition_neutral_proof.tex.

static double down(double x) { return std::nextafter(x, -INFINITY); }
static double up(double x) { return std::nextafter(x, INFINITY); }

static std::vector<int> prefix(int m, int a, int b) {
    std::vector<int> out;
    for (int z : {std::max(a,b), std::min(a,b)})
        if (z > 0) for (int j=0;j<m;++j) out.push_back(z);
    if (!out.empty()) out.pop_back(); // Feasibility before last positive label.
    return out;
}

static double state(int k, const std::vector<int>& x, double gamma) {
    std::vector<double> v(k,0.0);
    int used=0;
    for (int z : x) {
        double p=z/20.0;
        for(int c=std::min(k-1,used);c>=1;--c)
            v[c]+=p*std::max(0.0,gamma-1.0+v[c-1]-v[c]);
        v[0]+=p*gamma;
        ++used;
        if(v[k-1]>1.0-gamma) return v[k-1];
    }
    return v[k-1];
}

// Every bound encloses the exact real recurrence for probabilities z/20.
// F_x(u,v)=v+x[gamma-1+u-v]_+ is nondecreasing in u,v,x.
// We evaluate it at the all-lower/all-upper corners and round each operation
// outward. Early termination is safe because stop-loss values never decrease.
static std::pair<double,double> state_interval(int k,
             const std::vector<int>& x,double gamma) {
    std::vector<double> lo(k,0.0),hi(k,0.0);
    int used=0;
    for(int z : x) {
        double p=z/20.0;
        double pl=z==20?1.0:down(p), ph=z==20?1.0:up(p);
        for(int c=std::min(k-1,used);c>=1;--c) {
            double dl=down(down(down(gamma-1.0)+lo[c-1])-lo[c]);
            double dh=up(up(up(gamma-1.0)+hi[c-1])-hi[c]);
            lo[c]=std::max(0.0,down(lo[c]+down(pl*std::max(0.0,dl))));
            hi[c]=std::max(0.0,up(hi[c]+up(ph*std::max(0.0,dh))));
        }
        lo[0]=std::max(0.0,down(lo[0]+down(pl*gamma)));
        hi[0]=up(hi[0]+up(ph*gamma));
        ++used;
        if(lo[k-1]>up(1.0-gamma)) break;
    }
    return {lo[k-1],hi[k-1]};
}

int main() {
    static_assert(std::numeric_limits<double>::is_iec559,
                  "Outward rounding requires IEEE-754 double arithmetic");
    if (std::fegetround()!=FE_TONEAREST) return 2;
    std::cout<<std::setprecision(17);
    int k,m,a,b;
    while(std::cin>>k>>m>>a>>b) {
        if(a==0 && b==0) {std::cout<<"1 1 0 0 1\n";continue;}
        auto x=prefix(m,a,b);
        double lo=0.0,hi=1.0;
        for(int it=0;it<45;++it) {
            double mid=(lo+hi)/2;
            if(state(k,x,mid)<=1.0-mid) lo=mid; else hi=mid;
        }
        double root=(lo+hi)/2,delta=1e-11;
        double cl=0,ch=1,low_res=0,high_res=0;
        bool certified=false;
        for(int retry=0;retry<12;++retry) {
            cl=std::max(0.0,root-delta);
            ch=std::min(1.0,root+delta);
            auto L=state_interval(k,x,cl);
            auto U=state_interval(k,x,ch);
            low_res=L.second-down(1.0-cl);
            high_res=U.first-up(1.0-ch);
            bool lf=cl==0.0 || low_res<=0.0;
            bool uf=ch==1.0 || high_res>0.0;
            if(lf&&uf) {certified=true;break;}
            delta*=10;
        }
        std::cout<<cl<<" "<<ch<<" "<<low_res<<" "<<high_res<<" "<<certified<<"\n";
    }
}
