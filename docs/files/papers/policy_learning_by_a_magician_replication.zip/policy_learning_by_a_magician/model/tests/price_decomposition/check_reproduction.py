"""Read-only audit: rebuild in temporary paths and compare adopted certificates."""
from pathlib import Path
from fractions import Fraction
import argparse
import hashlib
import json
import math
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[3]
SRC=ROOT/'model/src/price_decomposition'
TEST=ROOT/'model/tests/price_decomposition'
OUT=ROOT/'model/generated/price_decomposition'


def run(*argv):
    result=subprocess.run(['python3',*map(str,argv)],cwd=ROOT,text=True,
                          stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError(result.stdout+'\n'+result.stderr)
    return result.stdout


def read(path):
    return json.loads(Path(path).read_text())


def verify_hashes(result):
    for key in ['inputs','source_hashes']:
        for path,digest in result.get(key,{}).items():
            assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest,path


def same(a,b,path=''):
    ignored={'seconds','elapsed_seconds','source_hashes','source_sha256','inputs'}
    if isinstance(a,dict):
        assert set(a)==set(b),path
        for key in a:
            if key not in ignored:same(a[key],b[key],path+'/'+key)
    elif isinstance(a,list):
        assert len(a)==len(b),path
        for i,(x,y) in enumerate(zip(a,b)):same(x,y,path+f'/{i}')
    elif isinstance(a,float):
        assert math.isclose(a,b,rel_tol=1e-11,abs_tol=2e-12),(path,a,b)
    else:
        assert a==b,(path,a,b)


def check_cap(temp):
    saved=read(OUT/'cap_bounds.json');verify_hashes(saved)
    run(SRC/'cap_run.py','--output-dir',temp)
    same(saved,read(temp/'cap_bounds.json'))
    same(read(OUT/'cap_exact_k5.json'),read(temp/'cap_exact_k5.json'))
    for r in saved['rows']:
        lo=Fraction(int(r['lower_numerator']),int(r['denominator']))
        hi=Fraction(int(r['upper_numerator']),int(r['denominator']))
        assert 0<lo<=hi<Fraction(17*r['n'],160)
    return {'capacities':[5,20,100,500],'exact_k5':True,
            'arithmetic':'integer directional bounds; exact Fraction cross-check'}


def check_neutral(temp):
    saved=read(OUT/'neutral.json');verify_hashes(saved)
    run(SRC/'neutral.py','--output',temp/'neutral.json')
    same(saved,read(temp/'neutral.json'))
    run(TEST/'neutral_checks.py','--output',temp/'neutral_checks.json')
    same(read(OUT/'neutral_checks.json'),read(temp/'neutral_checks.json'))
    for row in saved['settings']:
        assert len(row['all_candidates'])==441
        lo=Fraction(row['value_lower_exact']);hi=Fraction(row['value_upper_exact'])
        assert 0<lo<=hi and row['unique_winning_cutoff_certified']
        assert max(Fraction(r['welfare_upper_exact']) for r in row['all_candidates'])==hi
        assert max(Fraction(r['welfare_lower_exact']) for r in row['all_candidates']
                   if r['status']=='evaluated')==lo
    return {'capacities':[5,20,100,500],'candidates_each':441,
            'exact_endpoint_cases':343,'exhaustive_order_comparisons':1522,
            'arithmetic':'outward floating intervals with rational welfare aggregation'}


def check_lp(temp):
    saved=read(OUT/'lp_checks.json')
    assert hashlib.sha256((SRC/'lp.py').read_bytes()).hexdigest()==saved['source_sha256']
    run(SRC/'lp.py','--output',temp/'lp_checks.json')
    fresh=read(temp/'lp_checks.json');same(saved,fresh)
    for row in fresh['cap']:
        exact=json.loads(run(TEST/'cap_exact.py',row['k']))
        assert exact['exact_original_optimum_certified']
        assert abs(exact['lower']-row['value'])<2e-12
    return {'hard_cap_capacities':[1,2],'neutral_LP_cases':len(fresh['neutral']),
            'verification':'floating primal/dual residual checks; independent exact-DP agreement'}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--part',choices=['cap','neutral','lp','all'],default='all')
    args=parser.parse_args();report={}
    with tempfile.TemporaryDirectory(prefix='price-reproduction-') as tmp:
        temp=Path(tmp)
        for name,fn in [('cap',check_cap),('neutral',check_neutral),('lp',check_lp)]:
            if args.part in ['all',name]:report[name]=fn(temp)
    print(json.dumps({'status':'PASS','source_and_evidence_files_modified':False,
                      'checks':report},indent=2))


if __name__=='__main__':main()
