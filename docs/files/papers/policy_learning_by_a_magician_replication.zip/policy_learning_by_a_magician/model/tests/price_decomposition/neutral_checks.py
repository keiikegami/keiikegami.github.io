"""Independent exact-rational and exhaustive-order checks for the neutral solver."""
from fractions import Fraction as Q
from pathlib import Path
import itertools
import json
import random
import sys
import argparse

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/"model/src/price_decomposition"))
from neutral import Solver


def stoploss(labels,k,g):
    v=[Q(0)]*k
    for x in labels:
        old=v[:]
        v[0]+=x*g
        for c in range(1,k):v[c]+=x*max(Q(0),g-1+old[c-1]-old[c])
    return v


def positive_prefix(m,a,b):
    labels=sorted([Q(a,20)]*m+[Q(b,20)]*m,reverse=True)
    labels=[x for x in labels if x>0]
    return labels[:-1]


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--output",type=Path,default=ROOT/"model/generated/price_decomposition/neutral_checks.json");args=ap.parse_args()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    solver=Solver();cases=0
    try:
        for k,m in [(1,1),(1,2),(1,5),(2,2),(2,4),(3,6),(5,10)]:
            for a,b in itertools.product([0,1,3,5,10,15,20],repeat=2):
                lo,hi,_,_=solver.gamma(k,m,a,b)
                x=positive_prefix(m,a,b)
                vl=stoploss(x,k,lo)[-1]
                vh=stoploss(x,k,hi)[-1]
                assert vl<=1-lo,(k,m,a,b,'lower')
                assert hi==1 or vh>1-hi,(k,m,a,b,'upper')
                if k==1:
                    exact=Q(1)/(1+sum(x,Q()))
                    assert lo<=exact<=hi
                cases+=1
    finally:solver.close()
    # Exhaustively compare all orders for each small random multiset using
    # exact Fraction arithmetic. Include zeros, then remove them as required
    # by eligibility neutrality, rather than requiring zero-label openings.
    rng=random.Random(20261028)
    perm_checks=0
    for _ in range(40):
        labels=[Q(rng.choice([0,1,3,7,10]),10) for j in range(6)]
        labels=[x for x in labels if x>0]
        if not labels:continue
        k=rng.choice([1,2,3]);g=Q(rng.randint(1,19),20)
        desc=stoploss(sorted(labels,reverse=True)[:-1],k,g)
        for seq in set(itertools.permutations(labels)):
            other=stoploss(seq[:-1],k,g)
            assert all(x>=y for x,y in zip(desc,other)),(labels,k,g,seq)
            perm_checks+=1
    result={'status':'pass','exact_rational_endpoint_cases':cases,
            'exhaustive_permutation_comparisons':perm_checks,
            'scope':'Independent exact-Fraction endpoint feasibility checks; one-wand closed form; descending-order dominance for all unique permutations of 40 sampled small multisets; zeros included and then correctly removed.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(result)


if __name__=='__main__':main()
