"""Exact rational check for small capacities; not a simulation.

This independently implements the full 20-point Bellman expectation, rather
than the arithmetic-tail formula used by the C++ directional-rounding solver.
"""
from fractions import Fraction as F
import json
import sys

k = int(sys.argv[1]) if len(sys.argv) > 1 else 5
m = 2*k
reward = [[F(47+14*j,800) for j in range(20)],
          [F(-222+36*j,800) for j in range(20)]]
zero = [F(0)]*(k+1)

def T(f,s):
    return [F(0)]+[sum((max(f[l],f[l-1]+x) for x in reward[s]),F(0))/20
                    for l in range(1,k+1)]

v = [[None]*(m+1) for _ in range(m+1)]
for a in range(m+1):
    for b in range(m+1):
        if not a+b:
            v[a][b]=zero
        elif not a:
            v[a][b]=T(v[a][b-1],1)
        elif not b:
            v[a][b]=T(v[a-1][b],0)
        else:
            va,vb=T(v[a-1][b],0),T(v[a][b-1],1)
            v[a][b]=[min(x,y) for x,y in zip(va,vb)]
f=zero
for s in [1]*m+[0]*m:
    f=T(f,s)
lo,hi=v[m][m][k],f[k]
print(json.dumps({"status":"exact_rational_sandwich", "k":k,"n":4*k,
                  "lower_rational":str(lo),"upper_rational":str(hi),
                  "lower":float(lo),"upper":float(hi),
                  "exact_original_optimum_certified":lo==hi}))
